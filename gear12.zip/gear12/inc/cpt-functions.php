<?php
    // Gear Service Post
    add_action( 'init', 'gear_service_post_type_callback' );
    function gear_service_post_type_callback() {
        $labels = array(
            'name'               => _x( 'Services', 'post type general name', 'gear' ),
            'singular_name'      => _x( 'Service', 'post type singular name', 'gear' ),
            'menu_name'          => _x( 'Services', 'admin menu', 'gear' ),
            'name_admin_bar'     => _x( 'Services', 'add new on admin bar', 'gear' ),
            'add_new'            => _x( 'Add New', 'Service', 'gear' ),
            'add_new_item'       => __( 'Add New Service', 'gear' ),
            'new_item'           => __( 'New Service', 'gear' ),
            'edit_item'          => __( 'Edit Service', 'gear' ),
            'view_item'          => __( 'View Service', 'gear' ),
            'all_items'          => __( 'All Services', 'gear' ),
            'search_items'       => __( 'Search Services', 'gear' ),
            'parent_item_colon'  => __( 'Parent Services:', 'gear' ),
            'not_found'          => __( 'No Service found.', 'gear' ),
            'not_found_in_trash' => __( 'No Service found in Trash.', 'gear' )
        );
        $args = array(
            'labels'             => $labels,
            'description'        => __( 'Description.', 'gear' ),
            'public'             => true,
            'publicly_queryable' => true,
            'exclude_from_search'=> false,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'service' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 20,
            'menu_icon'          => 'dashicons-admin-network',
            'supports'           => array( 'title', 'editor', 'thumbnail' )
        );
        register_post_type( 'service', $args );
    }

    // Gear Client Post
    add_action( 'init', 'gear_client_post_type_callback' );
    function gear_client_post_type_callback() {
        $labels = array(
            'name'               => _x( 'Clients', 'post type general name', 'gear' ),
            'singular_name'      => _x( 'Client', 'post type singular name', 'gear' ),
            'menu_name'          => _x( 'Clients', 'admin menu', 'gear' ),
            'name_admin_bar'     => _x( 'Clients', 'add new on admin bar', 'gear' ),
            'add_new'            => _x( 'Add New', 'Client', 'gear' ),
            'add_new_item'       => __( 'Add New Client', 'gear' ),
            'new_item'           => __( 'New Client', 'gear' ),
            'edit_item'          => __( 'Edit Client', 'gear' ),
            'view_item'          => __( 'View Client', 'gear' ),
            'all_items'          => __( 'All Clients', 'gear' ),
            'search_items'       => __( 'Search Clients', 'gear' ),
            'parent_item_colon'  => __( 'Parent Clients:', 'gear' ),
            'not_found'          => __( 'No Client found.', 'gear' ),
            'not_found_in_trash' => __( 'No Client found in Trash.', 'gear' )
        );
        $args = array(
            'labels'             => $labels,
            'description'        => __( 'Description.', 'gear' ),
            'public'             => true,
            'publicly_queryable' => true,
            'exclude_from_search'=> true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'client' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 20,
            'menu_icon'          => 'dashicons-admin-users',
            'supports'           => array( 'title', 'thumbnail' )
        );
        register_post_type( 'client', $args );
    }

    // Client Categories
    function client_taxonomy() {
        register_taxonomy(
            'client-cat',
            'client',
            array(
                'hierarchical'    => true,
                'label'           => 'Categories',
                'query_var'       => true,
                'rewrite'         => array(
                    'slug'        => 'client-cat',
                    'with_front'  => false
                )
            )
        );
    }
    add_action( 'init', 'client_taxonomy');

    // Gear In the News Post
    add_action( 'init', 'gear_news_post_type_callback' );
    function gear_news_post_type_callback() {
        $labels = array(
            'name'               => _x( 'News', 'post type general name', 'gear' ),
            'singular_name'      => _x( 'News', 'post type singular name', 'gear' ),
            'menu_name'          => _x( 'In the News', 'admin menu', 'gear' ),
            'name_admin_bar'     => _x( 'In the News', 'add new on admin bar', 'gear' ),
            'add_new'            => _x( 'Add New', 'News', 'gear' ),
            'add_new_item'       => __( 'Add New News', 'gear' ),
            'new_item'           => __( 'New News', 'gear' ),
            'edit_item'          => __( 'Edit News', 'gear' ),
            'view_item'          => __( 'View News', 'gear' ),
            'all_items'          => __( 'All News', 'gear' ),
            'search_items'       => __( 'Search News', 'gear' ),
            'parent_item_colon'  => __( 'Parent News:', 'gear' ),
            'not_found'          => __( 'No News found.', 'gear' ),
            'not_found_in_trash' => __( 'No News found in Trash.', 'gear' )
        );
        $args = array(
            'labels'             => $labels,
            'description'        => __( 'Description.', 'gear' ),
            'public'             => true,
            'publicly_queryable' => true,
            'exclude_from_search'=> true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'news' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 20,
            'menu_icon'          => 'dashicons-megaphone',
            'supports'           => array( 'title', 'editor', 'thumbnail' )
        );
        register_post_type( 'news', $args );
    }

    // Gear Project Case Study Post
    add_action( 'init', 'gear_project_post_type_callback' );
    function gear_project_post_type_callback() {
        $labels = array(
            'name'               => _x( 'Projects', 'post type general name', 'gear' ),
            'singular_name'      => _x( 'Project', 'post type singular name', 'gear' ),
            'menu_name'          => _x( 'Projects', 'admin menu', 'gear' ),
            'name_admin_bar'     => _x( 'Projects', 'add new on admin bar', 'gear' ),
            'add_new'            => _x( 'Add New', 'Project', 'gear' ),
            'add_new_item'       => __( 'Add New Project', 'gear' ),
            'new_item'           => __( 'New Project', 'gear' ),
            'edit_item'          => __( 'Edit Project', 'gear' ),
            'view_item'          => __( 'View Projects', 'gear' ),
            'all_items'          => __( 'All Projects', 'gear' ),
            'search_items'       => __( 'Search Projects', 'gear' ),
            'parent_item_colon'  => __( 'Parent Projects:', 'gear' ),
            'not_found'          => __( 'No Project found.', 'gear' ),
            'not_found_in_trash' => __( 'No Project found in Trash.', 'gear' )
        );
        $args = array(
            'labels'             => $labels,
            'description'        => __( 'Description.', 'gear' ),
            'public'             => true,
            'publicly_queryable' => true,
            'exclude_from_search'=> false,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'project' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 20,
            'menu_icon'          => 'dashicons-welcome-learn-more',
            'supports'           => array( 'title', 'editor', 'thumbnail' )
        );
        register_post_type( 'project', $args );
    }

    // Project Categories
    function project_taxonomy() {
        register_taxonomy(
            'project-type',
            'project',
            array(
                'hierarchical'    => true,
                'label'           => 'Project Types',
                'query_var'       => true,
                'rewrite'         => array(
                    'slug'        => 'project-type',
                    'with_front'  => false
                )
            )
        );
    }
    add_action( 'init', 'project_taxonomy');
?>