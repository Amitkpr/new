
jQuery(document).ready(function(){
	
	jQuery(".right_panel_1").mCustomScrollbar({
	  mouseWheelPixels: 300 //change this to a value, that fits your needs
	})

	var newh = jQuery(window).height();
	jQuery('.right_panel_1').height(newh);	

	jQuery('.sortingc').click(function(){
		jQuery('#sorting').toggleClass('active');
	});

	jQuery('.sortbyascwrapper').click(function(){
		jQuery('.sortingc').addClass('acs');
		jQuery('.sortingc').removeClass('desc');
	});

	jQuery('.sortbydeswrapper').click(function(){
		jQuery('.sortingc').addClass('desc');
		jQuery('.sortingc').removeClass('acs');
	});
	
	jQuery(window).scroll(function(){
		var scroll_top =  jQuery(this).scrollTop(); // get scroll position top
		var height_element_parent =  jQuery(".stickyWrap").parent().outerHeight(); //get high parent element
		var height_element = jQuery(".stickyWrap").height(); //get high of elemeneto
		var position_fixed_max = height_element_parent - height_element; // get the maximum position of the elemen
		var position_fixed = scroll_top < 80 ? 80 - scroll_top : position_fixed_max > scroll_top ? 0 : position_fixed_max - scroll_top ;

		jQuery(".stickyWrap").css("top",position_fixed);
	});
	
	jQuery(".new_style_property .borderwrap:nth-child(even)").css("background-color", "#f3f3f3");  
	var heightElement = jQuery(".stickyWrap").height();
	jQuery('.newFilters').css('top',heightElement);
	
	jQuery('#showingCountnow').html(' ');
	var count = jQuery("#propertyListingTbl tbody tr" ).size();
	jQuery('#showingCountnow').html(count);	
	
	/* if(count == 1){
		jQuery('#propertyListingTbl_wrapper').css('height','500px');
	} */
	
	setTimeout(function(){ 
	
		var w = jQuery('.main_container_search .right_panel_1').width();
		jQuery('.stickyWrap').css('width',w);	
		jQuery('#propertyListingTbl').css('width',w);	
		var h = jQuery(window).height();
		jQuery('.map_img').css('height',h);
		jQuery('.map_img').css('overflow','hidden');
	
	}, 2000);
	
	 
	
	var saved = jQuery('.right_panel_1 .savedToggle');
	var unsaved = jQuery('.right_panel_1 .regularToggle');
	jQuery(saved).click(function(){
		jQuery(this).addClass('border_bottom');
		jQuery(unsaved).removeClass('border_bottom');
		jQuery('.right_panel_1 .tdWrap.saved').show();
		jQuery('.right_panel_1 .tdWrap.unsaved').hide();
		jQuery('.ajax_remove').show();
		jQuery('.ajax_saved').hide();
	});
	jQuery(unsaved).click(function(){
		jQuery(this).addClass('border_bottom');
		jQuery(saved).removeClass('border_bottom');
		jQuery('.right_panel_1 .tdWrap.saved').hide();
		jQuery('.right_panel_1 .tdWrap.unsaved').show();
		jQuery('.ajax_remove').hide();
		jQuery('.ajax_saved').show();
	});
	
	var owl = jQuery(".owl-carousel");
	owl.on('changed.owl.carousel',function(property){
		var current = property.item.index;
		var src = jQuery(property.target).find(".owl-item").eq(current).find("img").attr('src');
		var count = jQuery(property.target).find(".owl-item").eq(current).find('.sliderContainer').attr('rel'); 
		var changeCount = jQuery(property.target).find(".owl-item").eq(current).find('.sliderContainer').attr('data'); 
		jQuery('.my_count_'+changeCount).html(count);
	});	

	var table = jQuery('#propertyListingTbl').DataTable({
		"pagingType": "full_numbers",
		"lengthMenu": [[6, 12, 25, -1], [4, 16, 32,"All"]],
		'iDisplayLength': 10,
		language: {
			searchPlaceholder: "Search Records By Purchase Price, Sqft."
		}												
	});
	
	/*filters starts here*/
	jQuery.fn.dataTable.ext.search.push(
		function( settings, data, dataIndex ) {
				var min = parseInt( jQuery('#min').val(), 10 );
				var max = parseInt( jQuery('#max').val(), 10 );
				var Price = parseFloat( data[0] ) || 0; // use data for the age column
			/* alert(Price); */

			if ( ( isNaN( min ) && isNaN( max ) ) ||
				( isNaN( min ) && Price <= max ) ||
				( min <= Price   && isNaN( max ) ) ||
				( min <= Price   && Price <= max ) )
			{
				return true;
			}								
			return false;
		}
	);	
	jQuery.fn.dataTable.ext.search.push(
		function( settings, data, dataIndex ) {
			var min = parseInt( jQuery('#Bedsmin').val(), 10 );
			var max = parseInt( jQuery('#Bedsmax').val(), 10 );
			var Beds = parseFloat( data[1] ) || 0; // use data for the age column
			
			if ( ( isNaN( min ) && isNaN( max ) ) ||
				( isNaN( min ) && Beds <= max ) ||
				( min <= Beds   && isNaN( max ) ) ||
				( min <= Beds   && Beds <= max ) )
			{
				return true;
			}								
			return false;
		} 
	);	
	jQuery.fn.dataTable.ext.search.push(
		function( settings, data, dataIndex ) {
			var min = parseInt( jQuery('#Bathsmin').val(), 10 );
			var max = parseInt( jQuery('#Bathsmax').val(), 10 );
			var Beds = parseFloat( data[2] ) || 0; // use data for the age column
			
			if ( ( isNaN( min ) && isNaN( max ) ) ||
				( isNaN( min ) && Beds <= max ) ||
				( min <= Beds   && isNaN( max ) ) ||
				( min <= Beds   && Beds <= max ) )
			{
				return true;
			}								
			return false;
		} 
	);	
	
	jQuery('#min, #max').on('change',function() {
		table.draw();
	});		
	jQuery('#Bedsmin, #Bedsmax').on('change',function() {
		table.draw();
	});	
	jQuery('#Bathsmin, #Bathsmax').on('change',function() {
		table.draw();
	});	
	jQuery('.more_filters_wrap').click(function(){
		var icon = jQuery(this).find('i');
		if(jQuery(icon).hasClass('fa-angle-down')){
			jQuery(icon).removeClass('fa-angle-down');
			jQuery(icon).addClass('fa-angle-up');
		}else{
			jQuery(icon).removeClass('fa-angle-up');
			jQuery(icon).addClass('fa-angle-down');
		}
		jQuery('.newFilters').toggleClass('active');
	});	
	jQuery('.close, .applyfilters').click(function(){
		jQuery('.newFilters').removeClass('active');
	});
	jQuery('.sort,.sortby,.sortval').change(function() { 							
		var orderType = jQuery(".sortby:checked").val();
		var col = jQuery(".sort:checked").val();													
		table.order([col, orderType]).draw();
	});		
	jQuery('.rowicons_div .common_home').click(function(){
		jQuery('.common_home').removeClass('active');
		jQuery(this).addClass('active');
	});
	
	jQuery('.hometypes').on('change',function () {
		table.columns(7).search(this.value).draw();
	});
	
	/*Save properties in favroit list*/
	jQuery('.ajax_saved').click(function(){
		jQuery(this+' .custom_loader').show();
		var x;
		var pid = jQuery(this).attr('data-id');
		var user_id = jQuery(this).attr('rel');
		var status = jQuery(this).attr('val');
		var str = 'action=properties_status_saved_by_user&property_id=' + pid + '&user_id='+user_id+'&status='+status;
		jQuery.ajax({  
			context: this,      
			url: "<?php echo home_url();?>/wp-admin/admin-ajax.php",
			type: 'POST',             
			data: str,
			success: function(response) {
				jQuery(this+' .custom_loader').hide();
			}           
		});
	});
	
	/*Removed Properties in favroit list*/		
	jQuery('.ajax_remove').click(function(){
		jQuery(this+' .custom_loader').show();
		var x;
		var pid = jQuery(this).attr('data-id');
		var user_id = jQuery(this).attr('rel');
		var status = jQuery(this).attr('val');
		var str = 'action=properties_status_removed_by_user&property_id=' + pid + '&user_id='+user_id+'&status='+status;
		jQuery.ajax({  
			context: this,      
			url: "<?php echo home_url();?>/wp-admin/admin-ajax.php",
			type: 'POST',             
			data: str,
			success: function(response) {
				jQuery(this+' .custom_loader').hide();
				/* alert(response); */
			}           
		});
	});	
		
		
});
					