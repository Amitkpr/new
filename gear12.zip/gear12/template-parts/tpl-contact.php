<?php /* Template Name: Contact Template */ ?>

<?php get_header(); ?>

<div class="gear-contact-wrapper">
	<div class="gear-container">
		<h2 class="text-center">Get in Touch</h2>
		<div class="contact-column">
			<div class="contact-details">
				<label>Visit</label>
				<p>48 Elm Street<br>Stoneham, MA 02180</p>
			</div>
			<div class="contact-details">
				<label>New Business Inquiries</label>
				<p><a href="mailto: jen@gearcommunications.com">jen@gearcommunications.com</a></p>
			</div>
		</div>
		<div class="contact-image">
			<img src="">
		</div>
	</div>
</div>

<?php get_footer(); ?>