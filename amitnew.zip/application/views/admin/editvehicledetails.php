<?php 

$errorsData = $this->session->flashdata('errorsData');
$message = $this->session->flashdata('message');
$machineDetails = $machineDetails;
$role = $userdetails[0]['role'];

?>
<style>
.error{
	color:red;
	margin-bottom:0px;
}
.error p{
	margin-bottom:0px;
}
.common_input_field {
	width: 100%;
	border-radius: 5px;
	border: 1px solid #dddddd;
	height: 35px;
	padding: 5px;
}
.custom_check {
	background: #7CB67D;
	width: 28px;
	height: 28px;
	border-radius: 50%;
	text-align: center;
	line-height: 27px;
	color: #ffffff;
}
</style>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Main content -->
	<section class="content">
		<h1>Add Vehicle Details Here</h1>
		<!-- general form elements -->
		
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="box">
            <div class="box-header">
              <h3 class="box-title"><?php echo ucfirst($machineName); ?> Data</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="all_sites" class="table table-bordered table-hover">
                <thead>
                <tr>
					<th style="width:3%;vertical-align:middle;text-align:center;">Sr. No</th>
					<th style="width:4%;vertical-align:middle;text-align:center;">Model</th>
					<th style="width:4%;vertical-align:middle;text-align:center;">Door No.</th>
					<th style="width:7%;vertical-align:middle;text-align:center;">Vehicle No.</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Chasis No.</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Engine No.</th>
					
					<th style="width:5%;vertical-align:middle;text-align:center;">Purchase Date</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Tax</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Fitness</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Permit</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Insurance</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Insurer</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Finance</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Edit</th>
					<!--th style="width:5%;vertical-align:middle;text-align:center;">Status</th-->
                </tr>
                </thead>
                <tbody>
				<?php 
				$countMachinesDataNames = 1;
				foreach($machineDetails as $machineDetail){ 
				/* pt($machineDetail); */
					$id = $machineDetail->id;
					$cat_id = $machineDetail->cat_id;
					$model = $machineDetail->model;
					$dno = $machineDetail->dno;
					$vehicle_no = $machineDetail->vehicle_no;
					$chasis_no = $machineDetail->chasis_no;
					$engine_no = $machineDetail->engine_no;
					
					$pur_model = $machineDetail->pur_model;				
					$tax = $machineDetail->tax_due_date;				
					$fitness = $machineDetail->fitness_due_date;				
					$permit = $machineDetail->permit_due_date;				
					$insurance = $machineDetail->insurance_due_date;				
					$insurer = $machineDetail->insurer;				
					$finance = $machineDetail->finance;				
				?>
                <tr>
					<td><?php echo $countMachinesDataNames; ?></td>
					<td><?php echo $model; ?></td>
					<td><?php echo $dno; ?></td>
					<td><?php echo ($vehicle_no)?$vehicle_no:'N/A'; ?></td>
					<td><?php echo ($chasis_no)?$chasis_no:'N/A'; ?></td>
					<td><?php echo ($engine_no)?$chasis_no:'N/A'; ?></td>
					<td><?php echo ($pur_model)?$pur_model:'N/A'; ?></td>
					<td><input style="width:100%;" type="text" class="tax common_input_field common_date_picker" name="tax" value="<?php echo ($tax)?$tax:' '; ?>"></td>
					<td><input style="width:100%;" type="text" class="fitness common_input_field common_date_picker" name="fitness" value="<?php echo ($fitness)?$fitness:' '; ?>"></td>
					<td><input style="width:100%;" type="text" class="permit common_input_field common_date_picker" name="permit" value="<?php echo ($permit)?$permit:' '; ?>"></td>
					<td><input style="width:100%;" type="text" class="insurance common_input_field common_date_picker" name="insurance" value="<?php echo ($insurance)?$insurance:' '; ?>"></td>
					<td><input style="width:100%;" type="text" class="insurer common_input_field" name="insurer" value="<?php echo ($insurer)?$insurer:' '; ?>"></td>
					<td><input style="width:100%;" type="text" class="finance common_input_field" name="finance" value="<?php echo ($finance)?$finance:' '; ?>"></td>
					<!--td><a class="btn button update_machine" rel="<?php /* echo $id; */ ?>" style="background: #337ab7;color: #ffffff;">Update</a><img src="<?php/*  echo base_url(); */ ?>assets/admin/machines_icons/LoaderReal.gif" width="22px" height="22px" class="loadericon" style="display:none;"><i class="fa fa-check custom_check" style="display:none;"></i></td-->
					
					<td>
						<a class="btn button update_machine" href="<?php echo base_url(); ?>admin/dashboard/addvehicledetails/?edit=true&cat_id=<?php echo $cat_id; ?>&machine_id=<?php echo $id; ?>" style="background: #337ab7;color: #ffffff;">Edit</a>
					</td>
                </tr>
				<?php $countMachinesDataNames++; } ?>
                </tbody>
                <tfoot>
                <tr>
					<th style="width:3%;vertical-align:middle;text-align:center;">Sr. No</th>
					<th style="width:4%;vertical-align:middle;text-align:center;">Model</th>
					<th style="width:4%;vertical-align:middle;text-align:center;">Door No.</th>
					<th style="width:7%;vertical-align:middle;text-align:center;">Vehicle No.</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Chasis No.</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Engine No.</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Purchase Date</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Tax</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Fitness</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Permit</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Insurance</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Insurer</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Finance</th>
					<th style="width:5%;vertical-align:middle;text-align:center;">Edit</th>
					<!--th style="width:5%;vertical-align:middle;text-align:center;">Status</th-->
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
		</div>
		
	</section>
	<!-- /.content -->
</div>
  
