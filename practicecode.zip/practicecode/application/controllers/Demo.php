<?php 

if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Demo extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    //fetch user list here
    public function signup()
    {
        /* print_r($_FILES); */
        //$_POST = json_decode(file_get_contents("php://input"),true);
        if($this->input->post()){
            $input = $this->input->post();
            $this->form_validation->set_rules('name', 'name', 'trim|required|max_length[40]');
            $this->form_validation->set_rules('email', 'email', 'trim|required|valid_email');
            $this->form_validation->set_rules('username', 'username', 'trim|required|max_length[40]');
            $this->form_validation->set_rules('password', 'password', 'trim|required|max_length[40]');
            if ($this->form_validation->run() == false){
                $data['status'] = false;
                $errors                        = $this->form_validation->_error_array;
                $data['msg'] = array_values($errors)[0];
            }else{
                if($this->db->where('email',$input['email'])->get('users')->num_rows()>0)
                {
                    $data['status'] = false;
                    $data['msg'] ="This Email Alreday used";
                }
                else
                {
                    if($this->db->where('username',$input['username'])->get('users')->num_rows()>0)
                    {
                        $data['status'] = false;
                        $data['msg'] ="This Username Alreday used";
                    }
                    else
                    {
                        if($this->db->insert('users',$input))
                        {
                            $data['status'] = true;
                            $data['user'] = $input;
                        }
                        else
                        {
                            $data['status'] = false;
                            $data['msg'] ="Something went wrong";
                        }
                    }
                }
            }
        }
        else
        {
            $data['status'] = false;
            $data['msg'] ="Indirect Access not allowed";
        }
        exit(json_encode($data));
    }

    //fetch user list here
    public function login()
    {
        $_POST = json_decode(file_get_contents("php://input"),true);
        if($this->input->post())
        {
            $input = $this->input->post();
            $this->form_validation->set_rules('username', 'username', 'trim|required|max_length[40]');
            $this->form_validation->set_rules('password', 'password', 'trim|required|max_length[40]');
             if ($this->form_validation->run() == false)
            {
                $data['status'] = false;
                $errors                        = $this->form_validation->_error_array;
                $data['msg'] = array_values($errors)[0];
            }
            else
            {
                if($this->db->where('username',$input['username'])->get('users')->num_rows()<=0)
                {
                    $data['status'] = false;
                    $data['msg'] ="This Email is invalid";
                }
                else
                {
                    if($this->db->where('password',$input['password'])->get('users')->num_rows()<=0)
                    {
                        $data['status'] = false;
                        $data['msg'] ="The password is incorrect";
                    }
                    else
                    {
                        $result = $this->db->where(array('password'=>$input['password'],'username'=>$input['username']))->get('users')->row_array();
                        $data['status'] = true;
                        $data['user'] = $result;
                    }
                }
            }
        }
        else
        {
            $data['status'] = false;
            $data['msg'] ="Indirect Access not allowed";
        }
        exit(json_encode($data));
    }
}

?>