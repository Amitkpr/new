<?php 

$errorsData = $this->session->flashdata('errorsData');
$message = $this->session->flashdata('message');
$categoryNameDatas = $categoryNameData;	
$editCatDataResults = $editCatData;

?>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Main content -->
	<section class="content">
		<h1>Add Category name here</h1>
		<!-- general form elements -->
		<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pad0">
			<div class="box box-primary addpad">
				<div class="box-header with-border">
				  <h3 class="box-title">Category Data</h3>
				</div>
				<div style="padding:0px 15px;">
				<!-- /.box-header -->
				<?php
					if(isset($message['message']) && $message['check'] == 'f'){ ?>
					<div class="alert alert-danger">
					 <?php echo $message['message']; ?>
					</div>
				<?php }
				
				if(isset($message['message']) && $message['check'] == 't'){ ?>
				<div class="alert alert-success">
				  <?php echo $message['message']; ?>
				</div>
				<?php } 
				
				?>
				</div>
				<!-- form start -->
				<?php 
				
					if(!empty($editCatDataResults)){
						$editId = $editCatDataResults[0]->id;
						$editName = $editCatDataResults[0]->name;
						$editSlug = $editCatDataResults[0]->slug;
						$editNtype = $editCatDataResults[0]->n_type;
						$editSiteId = $editCatDataResults[0]->site_id;
						/* $editSiteName = $this->common_model->get_data_by_id('id','mines_sites', $editCatDataResults[0]->site_id); */
						$editIcon = $editCatDataResults[0]->icon_name;
						$base_url = base_url().'assets/admin/machines_icons/';
						$iconUrl = $base_url.$editIcon;
					}
					
					/* pt($siteNames); */
				?>
				<form method="POST" action="<?php echo base_url(); ?>admin/dashboard/addcategory" role="form" enctype="multipart/form-data">
					<input type="hidden" name="cat_id" value="<?php echo(isset($editId))?$editId:''; ?>">
					<input type="hidden" name="user_id" value="">
				  <div class="box-body">
					<div class="form-group">
						<label>Site Names</label>
						<select class="form-control select2" style="width: 100%;" name="site_id">
						<option>Select Site Name</option>
						<?php 
						
						foreach($siteNames as $siteNameData){ 
							$id = $siteNameData->id;
							$site_name = $siteNameData->name;
						?>
						  <option <?php echo(isset($editSiteId) && $editSiteId == $id )?"selected='selected'":''; ?> value="<?php echo $id; ?>"><?php echo $site_name; ?></option>
						<?php } ?>
						</select>
					</div>
					<div class="form-group">
					  <label for="machine_name">Category Name</label>
					  <input type="text" class="form-control" name="machine_name" id="machine_name" placeholder="Category name" value="<?php echo(isset($editName))?$editName:''; ?>">
					</div>
					<div class="form-group">
					  <label for="machine_slug">Category Slug</label>
					  <input type="text" class="form-control" name="machine_slug" id="machine_slug" placeholder="Category slug" value="<?php echo(isset($editSlug))?$editSlug:''; ?>">
					</div>
					<div class="form-group">
					  <label for="machine_slug">Number Type</label>
						<select class="form-control select2" required style="width: 100%;" name="n_type">
							<option>Select number type</option>
							<option <?php echo(isset($editNtype) && $editNtype == 'dno' )?"selected='selected'":''; ?> value="dno">D.No.</option>
							<option <?php echo(isset($editNtype) && $editSiteId == 'dno' )?"selected='selected'":''; ?> value="mno">M.No.</option>
						</select>
					</div>
					<div class="form-group">
					  <label for="machineicon" <?php echo(isset($iconUrl))?'style=display:block':''; ?>>Add icon</label>
					  <span <?php echo(isset($iconUrl))?'style=display:block;float:left;margin-right:15px;':''; ?>>
					  <?php echo(isset($iconUrl))?'<img src="'.$iconUrl.'" alt="icon" style="width:43px;height:49px;background:#337ab7;">':''; ?> 
					  </span><input <?php echo(isset($iconUrl))?'style=margin-top:17px;':''; ?> type="file" id="machineicon" name="userfile[]">
					</div>
				  </div>
				  <!-- /.box-body -->
				  <div class="box-footer">
					<button type="submit" class="btn btn-primary" ><?php echo(!empty($editCatDataResults))?'Update':'Submit'; ?></button>
				  </div>
				</form>
			</div>
			  <!-- /.box -->
		</div>
		<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
			<div class="box">
            <div class="box-header">
              <h3 class="box-title">All Machine</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="all_sites" class="table table-bordered table-hover">
                <thead>
                <tr>
					<th width="37px;">Sr. No</th>
					<th>Icon</th>
					<th>Category Name</th>
					<th>Site Name</th>
					<th>No. Type</th>
					<th>Edit</th>
					<th>Delete</th>
                </tr>
                </thead>
                <tbody>
				<?php 
				$countMachinesDataNames = 1;
				foreach($categoryNameDatas as $categoryData){ 
					$catId = $categoryData->id;
					$siteID = $categoryData->site_id;
					$n_type = $categoryData->n_type;
					$siteName = $this->common_model->get_data_by_id('id','mines_sites', $siteID);
					$base_url = base_url().'assets/admin/machines_icons/';
					$iconUrl = $base_url.$categoryData->icon_name;
				
				?>
                <tr>
                   <td><?php echo $countMachinesDataNames; ?></td>
                   <td><img src="<?php echo $iconUrl; ?>" alt="icon" style="width:43px;height:49px;background:#337ab7;"></td>
					<td><?php echo $categoryData->name; ?></td>
					<td><?php echo $siteName; ?></td>
					<td><?php if($n_type == 'dno'){echo 'D.No.'; }elseif($n_type == 'mno'){echo 'M.No.';} ?></td>
					<td><a href="<?php echo base_url(); ?>admin/dashboard/addcategory/?edit=true&id=<?php echo $catId; ?>" class="i_icon"><i class="fa fa-edit"></i></a></td>
					<td><a href="<?php echo base_url(); ?>admin/dashboard/addcategory/?delete=true&id=<?php echo $catId; ?>" class="i_icon"><i class="fa fa-trash-o"></i></a></td>
                </tr>
				<?php $countMachinesDataNames++; } ?>
                </tbody>
                <tfoot>
                <tr>
					<th>Sr. No</th>
					<th>Icon</th>
					<th>Category Name</th>
					<th>Site Name</th>
					<th>No. Type</th>
					<th>Edit</th>
					<th>Delete</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
		</div>
	</section>
	<!-- /.content -->
</div>
  
