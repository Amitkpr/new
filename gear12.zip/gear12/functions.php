<?php
	// ReduxFramework Admin Panel
	if ( !class_exists( 'ReduxFramework' ) ) {
 		require_once( get_stylesheet_directory() . '/inc/admin-core/framework.php' );
	}
	if ( !isset( $redux_demo ) ) {
		require_once( get_stylesheet_directory() . '/inc/admin-core/admin-config.php' );
	}

	// Gear Custom Post Types and Shortcode Panel
  	require_once( get_stylesheet_directory() . '/inc/cpt-functions.php' );
  	require_once( get_stylesheet_directory() . '/inc/shortcode.php' );

  	// Adding WordPress Features
  	function gear_setup() {
  		// Make theme available for translation
  		load_theme_textdomain( 'gear' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the document title
		add_theme_support( 'title-tag' );

		// Enable support for Post Thumbnails on posts and pages
		add_theme_support( 'post-thumbnails' );

		// Enable Theme Menus
		register_nav_menus( array(
			'primary'    => __( 'Header Menu', 'gear' ),
			'footer'     => __( 'Footer Menu', 'gear' )
		) );

		// Switch default core markup for search form, comment form, and comments to output valid HTML5
		add_theme_support( 'html5', array( 'comment-form', 'comment-list', 'gallery', 'caption' ) );

		// Enable support for Post Formats
		add_theme_support( 'post-formats', array( 'aside', 'image', 'video', 'quote', 'link', 'gallery', 'audio' ) );
	}
	add_action( 'after_setup_theme', 'gear_setup' );

	// Register widget area
	function gear_widgets_init() {
		register_sidebar( array(
			'name'          => __( 'Blog Sidebar', 'gear' ),
			'id'            => 'sidebar-1',
			'description'   => __( 'Add widgets here to appear in your sidebar on Blog', 'gear' ),
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>'
		) );
	}
	add_action( 'widgets_init', 'gear_widgets_init' );

	// Enqueue scripts and styles
	function gear_scripts() {
		// Loading Style Files
		wp_enqueue_style( 'fa', get_template_directory_uri() . '/css/font-awesome.min.css', array(), '' );
		wp_enqueue_style( 'gear-style', get_stylesheet_uri() );
		wp_enqueue_style( 'gear-media', get_theme_file_uri( '/css/media.css' ), '', '' );

		// Loading JavaScript Files
		wp_enqueue_script( 'gear-script', get_theme_file_uri( '/js/jquery.js' ), array(), '', true );
		wp_enqueue_script( 'scripts-js', get_theme_file_uri( '/js/script.js' ), array(), '', true );
	}
	add_action( 'wp_enqueue_scripts', 'gear_scripts' );

	// Gear Pagination
	function gear_pagination( $numpages = '', $pagerange = '', $paged = '' ) {
        if( empty( $pagerange ) ) {
            $pagerange = 2;
        }
        global $paged;
        if( empty( $paged ) ) {
            $paged = 1;
        }
        if( $numpages == '' ) {
            global $wp_query;
            $numpages = $wp_query->max_num_pages;
            if( !$numpages ) {
                $numpages = 1;
            }
        }
        $pagination_args = array(
            'base'         => get_pagenum_link(1) . '%_%',
            'format'       => 'page/%#%',
            'total'        => $numpages,
            'current'      => $paged,
            'show_all'     => false,
            'end_size'     => 1,
            'mid_size'     => $pagerange,
            'prev_next'    => false,
            'type'         => 'plain',
            'add_args'     => false,
            'add_fragment' => ''
        );
        $paginate_links = paginate_links( $pagination_args );
        if( $paginate_links ) {
            echo "<nav class='gear-pagination'>";
                echo $paginate_links;
            echo "</nav>";
        }
    }
?>