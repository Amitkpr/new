<?php

// Common Messages For All Pages
$lang['success_title']               = "Success!";
$lang['error_title']                 = "Error!";
$lang['confirm_title']               = "Confirm!";
$lang['Delete_title']                = "Delete";
$lang['ac_msg']                      = "Activate";
$lang['de_msg']                      = "Deactivate";
$lang['common_error']                = "Invalid parameter. please try again.";
$lang['indirect_access']             = "No direct script access allowed.";
$lang['permissions_error']           = "you don't have permissions to perform this action";
$lang['please_fill_all']             = "Please fill all required fields";
$lang['something_wrong']             = "Something went wrong";
$lang['voucher_alreday_exist']       = "Voucher already exists";
$lang['in_used']                     = "Unable to Complete request";
$lang['chalan_number_alreday_Exist'] = "Chalan number alreday exsit";

//Login Page Messages
$lang['email_not_exsit']        = "Email does not exist.";
$lang['account_is_deactivated'] = "Your account has been deactivated by admin.";
$lang['passord_not_match']      = "Password did not match";
$lang['company_not_exist']      = "Company does not exist";
$lang['year_not_exist']         = "Financial year does not exist";

// Reset Password MEssages here
$lang['link_sent_message']        = "Change password mail has been sent on your registered email address.";
$lang['password_changes_success'] = "Password chnages successfully";
$lang['invalid_link']             = "Invalid link";

//Profile page Messsage here
$lang['choose_image']  = "Please choose image to upload";
$lang['image_updated'] = "Profile image updated successfully";
$lang['email_in_use']  = "Email alreday in used. Please enter another email address";

//Manage User Page Messages Here
$lang['user_added']   = "User successfully added";
$lang['user_updated'] = "User successfully updated";
$lang['user_deleted'] = "User successfully Deleted";

//Manage Roles Page Messages Here
$lang['role_added']       = "Role successfully added";
$lang['permission_empty'] = "Please choose permissions to continue";
$lang['role_name_unique'] = "Role name must be unique";
$lang['role_updated']     = "Role successfully updated";
$lang['role_deleted']     = "Role successfully Deleted";

//Manage Company page Messages Here
$lang['company_added']          = "Company successfully added";
$lang['company_name_unique']    = "Company name must be unique";
$lang['company_updated']        = "Company successfully updated";
$lang['company_deleted']        = "Company successfully Deleted";
$lang['company_change_success'] = "company data has been changed successfully.";

//Master Size Page Messages Here
$lang['size_added']       = "Size successfully added";
$lang['size_name_unique'] = "Size must be unique";
$lang['size_updated']     = "Size successfully updated";
$lang['size_deleted']     = "Size successfully Deleted";

//Master Shade page Messages Here
$lang['shade_added']       = "Shade successfully added";
$lang['shade_name_unique'] = "Shade must be unique";
$lang['shade_updated']     = "Shade successfully updated";
$lang['shade_deleted']     = "Shade successfully Deleted";

//Master Brand page Messages Here
$lang['brand_added']       = "Brand successfully added";
$lang['brand_name_unique'] = "Brand must be unique";
$lang['brand_updated']     = "Brand successfully updated";
$lang['brand_deleted']     = "Brand successfully deleted";

//Master Design page Messages Here
$lang['design_added']       = "Design successfully added";
$lang['design_name_unique'] = "Design must be unique";
$lang['design_updated']     = "Design successfully updated";
$lang['design_deleted']     = "Design successfully deleted";

//Master Item type  page Messages Here
$lang['item_type_added']       = "Item type successfully added";
$lang['item_type_name_unique'] = "Item type must be unique";
$lang['item_type_updated']     = "Item type successfully updated";

//Master Item Category Page  Messages Here
$lang['item_category_added']       = "Item category successfully added";
$lang['item_category_name_unique'] = "Item category must be unique";
$lang['item_category_updated']     = "Item category successfully updated";
$lang['item_category_deleted']     = "Item category successfully deleted";

//Master Party  Page Message here
$lang['choose_profile_pic'] = "Please choose party profile pic";
$lang['party_added']        = "Party successfully added";
$lang['party_updated']      = "Party successfully updated";
$lang['party_deleted']      = "Party successfully deleted";

//Master  Design page Messages Here
$lang['process_added']       = "Process successfully added";
$lang['process_name_unique'] = "Process must be unique";
$lang['process_updated']     = "Process successfully updated";
$lang['process_deleted']     = "Process successfully deleted";

//Master  unit page Messages Here
$lang['unit_added']               = "Unit successfully added";
$lang['unit_name_unique']         = "Unit must be unique";
$lang['unit_updated']             = "Unit successfully Update";
$lang['relation_dublicate_error'] = "Relation must be unique";
$lang['unit_deleted']             = "Unit successfully deleted";

// Manage Lot number Messages
$lang['lot_no_dublicate_error'] = "Lot no must be unique";
$lang['lot_no_already_Exist']   = "Lot no alreday Exsit";
$lang['lot_number_added']       = "Lot successfully added";
$lang['lot_deleted']            = "Lot successfully deleted";

//Master Item Master  Page Here
$lang['item_master_added']          = "Item successfully added";
$lang['item_master_name_unique']    = "Item name must be unique";
$lang['item_master_updated']        = "Item successfully Update";
$lang['item_master_deleted']        = "Item successfully Update";
$lang['process_dublicate_error']    = "Process must be unique";
$lang['process_added_successfully'] = "Process successfully added";

//Price List Page  Here
$lang['price_alreay_exist'] = "Price for this date alreday exsit";
$lang['price_list_added']   = "Price list successfully added";
$lang['mending_process_updated']   = "Mending process updated successfully";
$lang['price_list_deleted']   = "Price list successfully deleted";

//Production List Page messages Here
$lang['production_added'] = "Production inserted successfully";

//Payment Verify Page Messages  Here
$lang['paid_amount_large']        = "Paid amount is greater then Due Amount";
$lang['payment_alreday_verified'] = "Payment alreday verified";
$lang['invalid_voucher']          = "invalid voucher number";
$lang['payment_verified_success'] = "Payment has been verified";
$lang['amount_acnnot_be_zero']    = "Payment can not be 0";

//Payment Entry Page  Messages  Here
$lang['payment_entry_inserted'] = "Payment entry successfully added";
$lang['payment_entry_updated']  = "Payment entry successfully updated";
$lang['payment_entry_deleted']  = "Payment entry successfully deleted";

//Transfer Entry Page  Messages  Here
$lang['transfer_entry_inserted'] = "Transfer entry successfully added";
$lang['transfer_entry_updated']  = "Transfer entry successfully updated";

//Receipt Pages Messages here
$lang['receipt_entry_inserted'] = "Receipt entry successfully added";
$lang['receipt_entry_updated']  = "Receipt entry successfully updated";
$lang['receipt_updated']        = "Receipt entry successfully updated";

//Lot Number Report Messages here
$lang['start_date_and_end_date'] = "Please choose Start date or End Date";

//bulk lot Messages here
$lang['bulk_lot_added'] = "Bulk lot added";

//Ledger Update Price
$lang['please_select_date']       = "Please select start date or end date";
$lang['production_type_required'] = "Please select price type";
$lang['production_List_required'] = "Please select atleast one Production to update price list";

//Registartion Mail Templates
$lang['register_mail_subject'] = "Registration Mail";
$lang['register_mail_content'] = "Hi User_Name__ <br> you are successfully registered on " . COMPANY_NAME . " <br> Your login details are as following: <br> Email or Username: User_Email__ <br>Password: User_Password__ <br>";

//Reset Password Mail and Messages
$lang['reset_mail_subject'] = "Reset Password Mail";
$lang['reset_mail_content'] = "Someone requested that the password to be reset for the following account:<br> Username: User_Email__ <br> If this was a mistake, just ignore this email and nothing will happen.<br>";
