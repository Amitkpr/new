<!DOCTYPE html>
<html>
<head>
	<title><?php if( is_home() || is_front_page() || is_404() ) { bloginfo( 'name' ); } else { echo get_the_title() . ' | ' . get_bloginfo( 'name' ); } ?></title>

	<!-- Adding Meta -->
	<meta charset="UTF-8">
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

	<!-- Adding Favicon -->
	<?php global $gear_options, $post; ?>
	<?php $favicon = $gear_options['favicon']['url']; ?>
	<link href="<?php echo $favicon; ?>" rel="apple-touch-icon">
	<link href="<?php echo $favicon; ?>" rel="icon">

	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

	<div class="gear-loader"><div class="preloader"></div></div>

	<!-- Gear Banner -->
	<?php if( is_home() || is_front_page() ) { ?>
	<?php $banner_image = get_field( 'banner_image', $post->id, true ); ?>
	<div class="gear-banner" style="background-image: url(<?php echo $banner_image['url']; ?>)">
		<div class="gear-container">
			<?php echo get_field( 'banner_content', $post->id, true ); ?>
		</div>
	</div>
	<?php } ?>
	
	<!-- Gear Header -->
	<header class="gear-header">
		<div class="gear-container">
			<div class="gear-brand">
				<?php $logo = $gear_options['logo']['url']; ?>
				<a href="<?php echo home_url(); ?>"><img src="<?php echo $logo; ?>"></a>
			</div>
			<nav class="gear-navigation">
				<span class="mobile-menu"><span class="m-icon"></span><span class="m-icon"></span><span class="m-icon"></span></span>
				<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false ) ); ?>
			</nav>
		</div>
	</header>

	<div class="gear-page-wrapper">