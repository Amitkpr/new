<?php 

$errorsData = $this->session->flashdata('errorsData');
$message = $this->session->flashdata('message');
$machineDetails = $machineDetails;
$role = $userdetails[0]['role'];

?>
<style>
.first_block {
	float: left;
	width: 100%;
	height: 91px;
}
.first_block .left_icon_block img{
	width: 44px;
	-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
    filter: grayscale(100%);
}
.first_block .left_icon_block{
	padding-left: 10px;	
}
.left_icon_block {
	background: #565556;
	float: left;
	padding: 7px;
	width: 30%;
	height: 100%;
	border-radius: 4px 0 0 4px;
}
.right_icon_content {
	float: left;
	width: 70%;
	padding: 18px 10px;
	color: #ffffff;
	height: 100%;
	border-radius: 0px 4px 4px 0px;
	font-size: 18px;
}
.value_of_lable {
	font-size: 22px;
	font-weight: bold;
}
.left_icon_block {
	vertical-align: middle;
	padding-top: 24px;
}
.img_wrap {
	float: left;
	width: 70%;
	background: #f1f1f1;
	height: 90px;
	border-radius: 4px;
	position: relative;
	padding: 3px;
	border: 2px solid #ffffff;
	box-shadow: 0px 0px 17px 5px #DADADA;
}
.img_wrap i {
	position: absolute;
	right: -12px;
	bottom: -9px;
	background: #ffffff;
	width: 23px;
	height: 23px;
	border-radius: 18px;
	color: #959595;
	line-height: 24px;
	padding-left: 5px;
}
.blue_bg{
	background: #00c0ed;
}
.green_bg{
	background: #4fb548;
}
.grey{
	background:#565656;
}
.yellow{
	background:#fbc300;
}
.title_of_block {
	text-align: center;
	display: block;
	width: 100%;
	color: #ffffff;
	font-size: 22px;
	height: 50px;
	padding-top: 10px;
	text-transform: uppercase;
	/* font-weight: re; */
}
.box_next_wrap {
	float: left;
	width: 100%;
	background: #ffffff;
	padding: 20px 15px;
}
.forth_left_block {
	float: left;
	width: 70%;
	padding-right: 50px;
}
.forth_right_block {
	float: left;
	width: 30%;
}
.forth_right_block label {
	font-size: 17px;
	text-transform: uppercase;
	color: #565656;
	font-weight: 500;
	text-align: center;
	display: block;
}
.image_wrap {
	background: #f1f1f1;
	text-align: center;
	text-transform: uppercase;
	height: 129px;
	border: 5px solid #d9d9d9;
	line-height: 22px;
	font-size: 18px;
	color: #565656;
	padding-top: 37px;
	overflow: hidden;
	position: relative;
}
.date_block {
	width: 100%;
	float: left;
	margin-bottom: 10px;
}
.date_block label{
	display: block;
	float: left;
	width: 100%;
	font-size: 18px;
	text-transform: uppercase;
	color: #565656;
	font-weight: 500;
}
.date_input_wrap {
	float: left;
	width: 100%;
	border: 1px solid #dddddd;
	height: 43px;
	border-radius: 4px;
	padding: 1px 28px 1px 10px;
	position: relative;
}
.date_input_wrap input {
	border: 1px solid transparent;
	width: 100%;
	float: left;
	height: 100%;
}
.date_input_wrap .fa {
	position: absolute;
	right: 10px;
	top: 13px;
	color: #7B7B7B;
}
.submit_button {
	max-width: 175px;
	width: 100%;
	height: 57px;
	font-size: 23px;
	text-transform: capitalize;
	background: #4fb548;
	color: #ffffff;
	border: 1px solid #4fb548;
	border-radius: 4px;
}
.title_of_block{
	border-radius: 4px 4px 0 0;
}
.photo_edit_title {
	color: #a0a0a0;
	font-size: 17px;
	text-align: center;
	display: block;
	padding-top: 27px;
}
.file_common_cls {
	position: absolute;
	top: 0;
	bottom: 0;
	height: 100%;
	width: 100%;
	float: left;
	opacity:0;
	cursor:pointer;
}
</style>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Main content -->
	<section class="content">
		<div class="col-lg-12"><div class="col-lg-12"><h1>Edit Vehicle Details</h1></div></div>
		<?php
			/* pt($machineName);	
				 */
		/* 	[0] => stdClass Object
        (
            [id] => 1
            [site_id] => 0
            [cat_id] => 1
            [model] => FM 400
            [dno] => 162
            [vehicle_no] => CG 13L 9655
            [chasis_no] => 8898843
            [engine_no] => 283054
            [pur_model] => undefined
            [tax] => 03/24/2018
            [fitness] => 03/22/2018
            [permit] => 03/29/2018
            [insurance] => 03/28/2018
            [insurer] => fasf
            [finance] => asdf
            [created_date] => 2006-03-18 13:00:00
            [modified_date] => 2015-03-18 01:31:00
        ) */	 
			/* pt($machineDetails);	 */ 
			$base_url = base_url().'assets/admin/machines_icons/'.$machineName;
			$icon_base_url = base_url().'assets/admin/machines_details/';
		?>
		<!-- general form elements -->
		<form method="" action="">
			<input type="hidden" name="edit" value="true">
			<input type="hidden" name="cat_id" value="<?php echo $machineDetails[0]->cat_id; ?>">
			<input type="hidden" name="machine_id" value="<?php echo $machineDetails[0]->id; ?>">
			<div class="col-lg-12">
				<div class="col-lg-2">
					<div class="first_block">
						<div class="left_icon_block">
							<img src="<?php echo $base_url; ?>">	
						</div>
						<div class="right_icon_content blue_bg">
							<span class="name_lable">Vehicle no.</span><br/>
							<span class="value_of_lable"><?php echo $machineDetails[0]->vehicle_no; ?></span>
						</div>
					</div>
				</div>
				<div class="col-lg-2">
					<div class="img_wrap">
						<span class="photo_edit_title">click to add photo</span>
						<i class="fa fa-pencil"></i>
					</div>	
				</div>
			</div>
			<div class="clearfix" style="margin-bottom:35px;"></div>
			<div class="col-lg-12">
				<div class="col-lg-2">
					<div class="first_block">
						<div class="left_icon_block">
							<img src="<?php echo $icon_base_url.'truck.png'; ?>">	
						</div>
						<div class="right_icon_content blue_bg">
							<span class="name_lable">Model no.</span><br/>
							<span class="value_of_lable"><?php echo $machineDetails[0]->model; ?></span>
						</div>
					</div>
				</div>
				<div class="col-lg-2">
					<div class="first_block">
						<div class="left_icon_block">
							<img src="<?php echo $icon_base_url.'Engine.png'; ?>">	
						</div>
						<div class="right_icon_content green_bg">
							<span class="name_lable">Engine no.</span><br/>
							<span class="value_of_lable"><?php echo $machineDetails[0]->engine_no; ?></span>
						</div>
					</div>
				</div>
				<div class="col-lg-2">
					<div class="first_block">
						<div class="left_icon_block">
							<img src="<?php echo $icon_base_url.'Door.png'; ?>">	
						</div>
						<div class="right_icon_content blue_bg">
							<span class="name_lable">Door no.</span><br/>
							<span class="value_of_lable"><?php echo $machineDetails[0]->dno; ?></span>
						</div>
					</div>
				</div>
				<div class="col-lg-2">
					<div class="first_block">
						<div class="left_icon_block">
							<img src="<?php echo $icon_base_url.'chesis.png'; ?>">	
						</div>
						<div class="right_icon_content green_bg">
							<span class="name_lable">Chesis no.</span><br/>
							<span class="value_of_lable"><?php echo $machineDetails[0]->chasis_no; ?></span>
						</div>
					</div>
				</div>
				<div class="col-lg-2">
					<div class="first_block">
						<div class="left_icon_block">
							<img src="<?php echo $icon_base_url.'calender.png'; ?>">	
						</div>
						<div class="right_icon_content blue_bg">
							<span class="name_lable">Purchase date.</span><br/>
							<span class="value_of_lable"><?php echo $machineDetails[0]->pur_model; ?></span>
						</div>
					</div>
				</div>
			</div>
			
			<div class="clearfix" style="margin-bottom:35px;"></div>
			<div class="col-lg-12">
				<div class="col-lg-8 pad0">
					<div class="col-lg-6">
						<div class="block_4_wrap">
							<span class="title_of_block grey">Tax</span>
							<div class="box_next_wrap">
								<div class="forth_left_block">
									<span class="date_block">
										<label>Due date</label>
										<span class="date_input_wrap"><input type="text" class="tax_due_date dateInput" id="tax_due_date" name="tax_due_date"><i class="fa fa-calendar" aria-hidden="true"></i></span>
									</span>
									<span class="date_block">
										<label>Challan No.</label>
										<span class="date_input_wrap"><input type="text" class="tax_challan_no" id="tax_challan_no" name="tax_challan_no"><i class="fa fa-file-text-o" aria-hidden="true"></i></span>
									</span>
								</div>
								<div class="forth_right_block">
									<label>Challan Photo</label>
									<div class="image_wrap">
										<input type="file" name="tax_challan_photo" class="file_common_cls">
										Add<br/>
										Photo
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="block_4_wrap">
							<span class="title_of_block green_bg">Fitness</span>
							<div class="box_next_wrap">
								<div class="forth_left_block">
									<span class="date_block">
										<label>Due date</label>
										<span class="date_input_wrap"><input type="text" class="fitness_due_date dateInput" id="fitness_due_date" name="fitness_due_date"><i class="fa fa-calendar" aria-hidden="true"></i></span>
									</span>
									<span class="date_block">
										<label>Receipt No.</label>
										<span class="date_input_wrap"><input type="text" class="fitness_challan_date" id="fitness_challan_date" name="fitness_challan_date"><i class="fa fa-file-text-o" aria-hidden="true"></i></span>
									</span>
								</div>
								<div class="forth_right_block">
									<label>Receipt Photo</label>
									<div class="image_wrap">
										<input type="file" name="fitness_challan_photo" class="file_common_cls">
										Add<br/>
										Photo
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="clearfix" style="margin-bottom:35px;"></div>
					<div class="col-lg-6">
						<div class="block_4_wrap">
							<span class="title_of_block green_bg">Permit</span>
							<div class="box_next_wrap">
								<div class="forth_left_block">
									<span class="date_block">
										<label>Due date</label>
										<span class="date_input_wrap"><input type="text" class="permit_due_date dateInput" id="permit_due_date" name="permit_due_date"><i class="fa fa-calendar" aria-hidden="true"></i></span>
									</span>
									<span class="date_block">
										<label>Receipt No.</label>
										<span class="date_input_wrap"><input type="text" class="permit_challan_date" id="permit_challan_date" name="permit_challan_date"><i class="fa fa-file-text-o" aria-hidden="true"></i></span>
									</span>
								</div>
								<div class="forth_right_block">
									<label>Permit Photo</label>
									<div class="image_wrap">
										<input type="file" name="permit_challan_photo" class="file_common_cls">
										Add<br/>
										Photo
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="block_4_wrap">
							<span class="title_of_block grey">Insurance</span>
							<div class="box_next_wrap">
								<div class="forth_left_block">
									<span class="date_block">
										<label>Due date</label>
										<span class="date_input_wrap"><input type="text" class="insurance_due_date dateInput" id="insurance_due_date" name="insurance_due_date"><i class="fa fa-calendar" aria-hidden="true"></i></span>
									</span>
									<span class="date_block">
										<label>Receipt No.</label>
										<span class="date_input_wrap"><input type="text" class="insurance_challan_date" id="insurance_challan_date" name="insurance_challan_date"><i class="fa fa-file-text-o" aria-hidden="true"></i></span>
									</span>
								</div>
								<div class="forth_right_block">
									<label>Permit Photo</label>
									<div class="image_wrap">
										<input type="file" name="insurance_challan_photo" class="file_common_cls">
										Add<br/>
										Photo
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="col-lg-12 pad0">
						<div class="block_4_wrap">
							<span class="title_of_block grey">Insurer</span>
							<div class="box_next_wrap">
								<span class="date_block">
									<label>Insurer Name</label>
									<span class="date_input_wrap"><input type="text" class="insurer" id="insurer" name="insurer"><i class="fa fa-shield" aria-hidden="true"></i></span>
								</span>
							</div>
						</div>
					</div>
					<div class="clearfix" style="margin-bottom:35px;"></div>
					<div class="col-lg-12 pad0">
						<div class="block_4_wrap">
							<span class="title_of_block green_bg">Finance</span>
							<div class="box_next_wrap">
								<span class="date_block">
									<label>Finance Company name</label>
									<span class="date_input_wrap"><input type="text" class="finance" id="finance" name="finance"><i class="fa fa-money" aria-hidden="true"></i></span>
								</span>
							</div>
						</div>
					</div>
					<div class="clearfix" style="margin-bottom:35px;"></div>
					<div class="col-lg-12 pad0">
						<input type="submit" class="submit_button" name="update" value="Update">
					</div>
				</div>				
			</div>
		</form>
		
	</section>
	<!-- /.content -->
</div>
  
