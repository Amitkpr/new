<?php /* Project Detail Page */ ?>

<?php get_header(); ?>
<?php global $post; ?>
<?php $panel_1 = get_field( 'show_panel_1', $post->id, true ); ?>
<?php $panel_2 = get_field( 'show_panel_2', $post->id, true ); ?>
<?php $panel_3 = get_field( 'show_panel_3', $post->id, true ); ?>
<?php $panel_4 = get_field( 'show_panel_4', $post->id, true ); ?>
<?php $panel_5 = get_field( 'show_panel_5', $post->id, true ); ?>
<?php $panel_6 = get_field( 'show_panel_6', $post->id, true ); ?>

<div class="gear-project-single text-center">

	<section class="gear-ps-top">
		<div class="gear-bg-lgrey gear-controller">
			<div class="gear-container">
				<?php $image_id  = get_post_thumbnail_id();
				$image_url = wp_get_attachment_image_src( $image_id, 'large', true ); ?>
				<figure><img src="<?php echo $image_url['0']; ?>"></figure>
			</div>
		</div>
		<div class="gear-container-small gear-ps-text">
			<?php while( have_posts() ): the_post() ?>
				<?php the_content(); ?>
			<?php endwhile; ?>
		</div>
	</section>

	<?php if( $panel_1 == 'show' ) { ?>
		<section class="gear-pr-panel">
			<div class="gear-container">
				<div class="gear-prp-text text-left prp-common">
					<h2><?php echo get_field( 'panel_heading_1', $post->id, true ); ?></h2>
					<p><?php echo get_field( 'panel_content_1', $post->id, true ); ?></p>
				</div>
				<div class="gear-prp-img text-right prp-common">
					<?php $prp_image = get_field( 'panel_image_1', $post->id, true ); ?>
					<img src="<?php echo $prp_image['url']; ?>">
				</div>
			</div>
		</section>
	<?php } ?>

	<?php if( $panel_2 == 'show' ) { ?>
		<?php $color = get_field( 'panel_2_background', $post->id, true ); ?>
		<section class="gear-bg-panel" <?php if( $color ) { echo 'style="background: '.$color.'"'; } ?>>
			<div class="gear-container">
				<h2 class="normal-heading"><?php echo get_field( 'panel_content_2', $post->id, true ); ?></h2>
			</div>
		</section>
	<?php } ?>

	<?php if( $panel_3 == 'show' ) { ?>
		<section class="gear-pr-panel padder-40">
			<div class="gear-container">
				<div class="gear-prp-text text-left prp-common">
					<?php $prp_image = get_field( 'panel_image_3', $post->id, true ); ?>
					<img src="<?php echo $prp_image['url']; ?>">
				</div>
				<div class="gear-prp-img text-left prp-common">
					<h2><?php echo get_field( 'panel_heading_3', $post->id, true ); ?></h2>
					<p><?php echo get_field( 'panel_content_3', $post->id, true ); ?></p>
				</div>
			</div>
		</section>
	<?php } ?>

	<?php if( $panel_4 == 'show' ) { ?>
		<section class="gear-pr-panel padder-40">
			<div class="gear-container-small">
				<h2 class="text-center"><?php echo get_field( 'panel_heading_4', $post->id, true ); ?></h2>
				<p class="padder-ob-120"><?php echo get_field( 'panel_content_4', $post->id, true ); ?></p>
			</div>
		</section>
	<?php } ?>

	<?php if( $panel_5 == 'show' ) { ?>
		<section class="gear-media-place gear-controller text-center gear-bg-lgrey padder-75">
			<div class="gear-container">
				<h2><?php echo get_field( 'panel_heading_5', $post->id, true ); ?></h2>
				<ul>
					<?php $images = get_field('media_placements');
					if( $images ):
						foreach( $images as $image ): ?>
							<li><img src="<?php echo $image['url']; ?>"></li>
						<?php endforeach;
					endif; ?>
				</ul>
			</div>
		</section>
	<?php } ?>

	<?php if( $panel_6 == 'show' ) { ?>
		<section class="gear-more-projects text-left gear-controller padder-75">
			<div class="gear-container">
				<h2 class="padder-40 text-center">More Projects</h2>
				<ul>
					<?php
						$terms = get_the_terms( $post->ID , 'project-type', 'string');
						$args = array(
							'tax_query' => array(
							    array(
							        'taxonomy' => 'project-type',
							        'terms' => $terms[0]->slug,
							        'field' => 'slug',
							        'operator' => 'IN'
							    )
							),
							'posts_per_page'   => 2,
							'orderby'          => 'post_date',
							'order'            => 'rand',
							'post_type'        => 'project',
							'post__not_in'	   => array($post->ID),
							'post_status'      => 'publish',
						);
						$query = new WP_Query( $args );
						if( $query->have_posts() ) :
							while( $query->have_posts() ) : $query->the_post(); ?>
								<li>
									<?php $img_id = get_post_thumbnail_id();
									$img_url = wp_get_attachment_image_src( $img_id, 'large', true ); ?>
									<figure><a href="<?php the_permalink(); ?>"><img src="<?php echo $img_url['0']; ?>"></a></figure>
									<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
									<div class="gear-upper"><a href="<?php the_permalink(); ?>">See what gear did</a></div>
								</li>
							<?php endwhile;
						endif;
						wp_reset_postdata();
					?>
				</ul>
			</div>
		</section>
	<?php } ?>

</div>

<?php get_footer(); ?>