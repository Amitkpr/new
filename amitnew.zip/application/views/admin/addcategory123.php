<?php 
$errorsData = $this->session->flashdata('errorsData');
$message = $this->session->flashdata('message');
$categoriesNameDatas = $categoriesNameData;
?>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Main content -->
	<section class="content">
		<h1>Add Category name here</h1>
		<!-- general form elements -->
		<div class="box box-primary">
			<div class="box-header with-border">
			  <h3 class="box-title">Category Data</h3>
			</div>
			<div style="padding:0px 15px;">
			<!-- /.box-header -->
			<?php
				if(isset($message['message']) && $message['check'] == 'f'){ ?>
				<div class="alert alert-danger">
				 <?php echo $message['message']; ?>
				</div>
			<?php }
			
			if(isset($message['message']) && $message['check'] == 't'){ ?>
			<div class="alert alert-success">
			  <?php echo $message['message']; ?>
			</div>
			<?php } 
			
			?>
			</div>
			<!-- form start -->
			<form method="POST" action="<?php echo base_url(); ?>admin/dashboard/addcategory" role="form">
				<input type="hidden" name="user_id" value="">
			  <div class="box-body">
				<div class="form-group">
				  <label for="site_name">Category Name</label>
				  <input type="text" class="form-control" name="site_name" id="site_name" placeholder="Site name">
				</div>
				<div class="form-group">
				  <label for="site_slug">Category Slug</label>
				  <input type="text" class="form-control" name="site_slug" id="site_slug" placeholder="Site slug">
				</div>
			
				<div class="form-group">
					<label>Site Names</label>
					<select class="form-control select2" style="width: 100%;" name="site_id">
					<option>Select Site Name</option>
					<?php 
					
					foreach($siteNames as $siteNameData){ 
						$id = $siteNameData->id;
						$site_name = $siteNameData->name;
					?>
					  <option value="<?php echo $id; ?>"><?php echo $site_name; ?></option>
					<?php } ?>
					</select>
				</div>
			  </div>
			  <!-- /.box-body -->
			  <div class="box-footer">
				<button type="submit" class="btn btn-primary">Submit</button>
			  </div>
			</form>
		</div>
          <!-- /.box -->
		  
		  <div class="box">
            <div class="box-header">
              <h3 class="box-title">All Categories</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="all_sites" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Sr. No</th>
                  <th>Category Name</th>
                  <th>Site Name</th>
                  <th>By User</th>
                  <th>Created Date</th>
                  <th>Updated Date</th>
                </tr>
                </thead>
                <tbody>
				<?php 
				$countSiteNames = 1;
				foreach($categoriesNameDatas as $categoriesData){ 
				$siteID = $categoriesData->site_id;
				$siteName = $this->common_model->get_data_by_id('id','mines_sites', $siteID);
				?>
                <tr>
                   <td><?php echo $countSiteNames; ?></td>
					<td><?php echo $categoriesData->name; ?></td>
					<td><?php echo $siteName; ?></td>
					<td><?php echo $siteName; ?></td>
					<td><?php echo $categoriesData->created_date; ?></td>
					<td><?php echo $categoriesData->modified_date; ?></td>
                </tr>
				<?php $countSiteNames++; } ?>
                </tbody>
                <tfoot>
                <tr>
                   <th>Sr. No</th>
                  <th>Site Name</th>
                  <th>By User</th>
                  <th>Created Date</th>
                  <th>Updated Date</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
	</section>
	<!-- /.content -->
</div>
  
