<?php
if (!defined('BASEPATH'))
{
    exit('No direct script access allowed');
}

function get_date_format($date)
{
    if ($date == '0000-00-00 00:00:00')
    {
        return "N/A";
    }
    else
    {
        $myDateTime           = DateTime::createFromFormat('Y-m-d H:i:s', $date);
        return $newDateString = $myDateTime->format('d-m-Y');
    }
}
function get_date_format_without_min($date)
{
    if ($date == '0000-00-00 00:00:00')
    {
        return "N/A";
    }
    else
    {
        $myDateTime           = DateTime::createFromFormat('Y-m-d H:i:s', $date);
        return $newDateString = $myDateTime->format('d-m-Y');
    }
}

function set_date_format($date)
{
    if ($date == '00-00-0000')
    {
        return "N/A";
    }
    else
    {
        $myDateTime           = DateTime::createFromFormat('d-m-Y', $date);
        return $newDateString = $myDateTime->format('Y-m-d h:i:s');
    }
}

function filter_date($date)
{
    if ($date == '00-00-0000')
    {
        return false;
    }
    else
    {
        $myDateTime           = DateTime::createFromFormat('d-m-Y', $date);
        return $newDateString = $myDateTime->format('Y-m-d');
    }
}

function randomPassword()
{
    $alphabet    = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass        = array();               //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 6; $i++)
    {
        $n      = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

//Link generate
function randomLink()
{
    $alphabet    = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass        = array();               //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 15; $i++)
    {
        $n      = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

function search_permission($id, $array)
{
    foreach ($array as $key => $val)
    {
        if ($val['Perm_Id'] === $id)
        {
            return true;
        }
    }
    return false;
}

function search_checked($id, $array, $keyword)
{
    foreach ($array as $key => $val)
    {
        if ($val['Perm_Id'] === $id)
        {
            if ($val[$keyword] == '1')
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    return false;
}

//Send Mail here
function send_email($from_email, $from_name, $mail_to, $mail_subject, $mail_content, $attach = "")
{
    $CI = &get_instance();

    $config['protocol'] = 'sendmail';
    $config['charset'] = 'iso-8859-1';
    $config['wordwrap'] = TRUE;
    $config['mailtype'] = 'html';
    $CI->email->initialize($config);
    $CI->email->from($from_email, $from_name);
    $CI->email->to($mail_to);
    $CI->email->subject($mail_subject);
    $CI->email->message($mail_content);
    $CI->email->set_mailtype('html');
    $CI->email->set_newline("\r\n");
    if (isset($attach) && !empty($attach))
    {
        $CI->email->attach($attach);
    }
    if ($CI->email->send())
    {
        return true;
    }
    else
    {
        return false;
    }
}

//User profile check
function image_exist($image)
{
    if (!file_exists($image))
    {
        return base_url(DEFAULT_IMAGE);
    }
    else
    {
        return base_url($image);
    }

}

function doc_exist($image)
{
    if (!file_exists($image))
    {
        return base_url(DEFAULT_DOCUMENT);
    }
    else
    {
        return base_url($image);
    }

}

function get_current_bal($id)
{
    $CI  = &get_instance();
    $sql = $CI->db->where('Party_Id', $id)->get('party');
    if ($sql->num_rows() > 0)
    {
        return $sql->row()->Balance;
    }
    else
    {
        return false;
    }
}

function get_compnies()
{
    $CI  = &get_instance();
    $where = array('Is_Deleted' => '0');
    return $CI->common_model->get_data('company', $where);
}

function get_financialyear()
{
    $CI  = &get_instance();
    $where = array('Year_Id!=' => '0');
    return $CI->common_model->get_data('years', $where);
}

function get_wherein($table, $coulumn, $array_items){
    $CI  = &get_instance();
    return $CI->common_model->select_where_in($table, $coulumn, $array_items);
}
