<?php /* Template Name: Case Study Interior */ ?>

<?php get_header(); ?>



<?php get_footer(); ?>