<?php /* Template Name: About Us Template */ ?>

<?php get_header(); ?>

	<section class="page-top-section">
		<div class="gear-container">
			<h1 class="gear-large-text">We are our clients’ biggest <br> champions and a bunch of <br> dog lovers.</h1>
		</div>
	</section>

	<section class="gear-department-marketing text-center">
		<div class="gear-container">
			<figure><img src="http://localhost/gear/wp-content/uploads/2017/09/Jennifer-Gear-and-Connie-Swaebe.jpg"></figure>
			<div class="gdm-content gear-middle-text">
				<h2>Jennifer Gear and Connie Swaebe</h2>
				<p class="text-left">Bio about Jen and Connie. We work closely with you as an extension of your marketing department, making sure that the public relations campaign meshes seamlessly with your entire marketing program. Everything we do focuses on helping you achieve your overall marketing goals, enhancing your brand, and shaping public opinion of your company’s products or services.</p>
			</div>
		</div>
	</section>

	<section class="gear-staff-members">
		<div class="gear-container">
			<div class="gsm-heading text-center">
				<h2 class="normal-heading">A team of motivated thinkers, creatives and doers, we <br> believe in the power of design and its ability to improve the <br> world. Together, with our strong network of expert <br> collaborators, we make a creative difference.</h2>
			</div>
			<div class="gsm-row">
				<div class="gsm-col">
					<div class="gsm-inner">
						<figure class="gsm-image"><img src="http://localhost/gear/wp-content/uploads/2017/09/Jennifer-01.jpg"></figure>
						<h2 class="gsm-name">Jennifer Gear <span>Founder, CEO</span></h2>
						<p class="gsm-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
					</div>
					<div class="gsm-inner">
						<figure class="gsm-image"><img src="http://localhost/gear/wp-content/uploads/2017/09/Jennifer-02.jpg"></figure>
						<h2 class="gsm-name">Jennifer Gear <span>Founder, CEO</span></h2>
						<p class="gsm-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
					</div>
				</div>
				<div class="gsm-col">
					<div class="gsm-inner">
						<figure class="gsm-image"><img src="http://localhost/gear/wp-content/uploads/2017/09/Jennifer-02.jpg"></figure>
						<h2 class="gsm-name">Jennifer Gear <span>Founder, CEO</span></h2>
						<p class="gsm-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
					</div>
					<div class="gsm-inner">
						<figure class="gsm-image"><img src="http://localhost/gear/wp-content/uploads/2017/09/Jennifer-01.jpg"></figure>
						<h2 class="gsm-name">Jennifer Gear <span>Founder, CEO</span></h2>
						<p class="gsm-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
					</div>
				</div>
				<div class="gsm-col">
					<div class="gsm-inner">
						<figure class="gsm-image"><img src="http://localhost/gear/wp-content/uploads/2017/09/Jennifer-01.jpg"></figure>
						<h2 class="gsm-name">Jennifer Gear <span>Founder, CEO</span></h2>
						<p class="gsm-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
					</div>
					<div class="gsm-inner">
						<figure class="gsm-image"><img src="http://localhost/gear/wp-content/uploads/2017/09/Jennifer-02.jpg"></figure>
						<h2 class="gsm-name">Jennifer Gear <span>Founder, CEO</span></h2>
						<p class="gsm-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="gear-motivated-team gear-bg-lgrey text-center gear-controller padder-75">
		<div class="gear-container">
			<figure><img src="http://localhost/gear/wp-content/uploads/2017/09/dogs_720.gif"></figure>
			<h2 class="normal-heading">A team of motivated thinkers, creatives and doers, we <br> believe in the power of design and its ability to improve the <br> world. Together, with our strong network of expert <br> collaborators, we make a creative difference.</h2>
		</div>
	</section>

	<section class="gear-victorian gear-controller text-center padder-75 gear-grey">
		<div class="gear-container">
			<figure><img src="http://localhost/gear/wp-content/uploads/2017/09/victorian-house.png"></figure>
			<div class="gv-col"><h2>The Gear Victorian</h2></div>
			<div class="gv-col"><p>Our 1920s Victorian home serves as the hub of Gear Communications. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p></div>
		</div>
	</section>


<?php get_footer(); ?>