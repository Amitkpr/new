<?php
class Common_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    //Insert Row
    public function insert_data($table, $data)
    {
        if ($this->db->insert($table, $data))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //Get User Info here
    public function get_data($table, $where, $option = "", $order_by = "")
    {
        $this->db->where($where);
        if (!empty($order_by))
        {
            $this->db->order_by($order_by, 'asc');
        }
        $sql = $this->db->get($table);
        if ($sql->num_rows() > 0)
        {
            if ($option == 'single')
            {
                return $sql->row_array();
            }
            else
            {
                return $sql->result_array();
            }
        }
        else
        {
            return false;
        }
    }

    //GEt Update data
    public function update_data($table, $data, $where)
    {
        if ($this->db->where($where)->update($table, $data))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public function check_data($table, $where)
    {
        if ($this->db->where($where)->get($table)->num_rows() <= 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public function delete_data($table, $where)
    {
        $this->db->where($where)->delete($table);
    }

    public function get_realtions($relation_of)
    {
        $where = array('Relation_Of' => $relation_of);
        $sql   = $this->db->select('r.*,u.Unit_Name,u.Unit_Code,u.Unit_Id')->from('unit_relations r')->join('units u', 'u.Unit_Id=r.Relation_With', 'left')->where($where)->get();
        if ($sql->num_rows() > 0)
        {
            return $sql->result_array();
        }
        else
        {
            return false;
        }
    }

    public function get_proceess_by_comma($id)
    {
        $data = $this->db->select('p.Process_Name')->from('item_process ip')->where('ip.Master', $id)->join('process p', 'p.Process_Id=ip.Process_Id', 'left')->get()->result_array();
        if (!empty($data))
        {
            $all = "";
            foreach ($data as $name)
            {
                $all .= $name['Process_Name'] . ", ";
            }
            $all = rtrim($all, ", ");
            return $all;
        }
        else
        {
            return "N/A";
        }
    }

    public function get_designs_by_comma($values)
    {
        $sql  = "SELECT * FROM `design` WHERE find_in_Set(`Design_Id`,'" . $values . "')";
        $data = $this->db->query($sql)->result_array();
        if (!empty($data))
        {
            $all = "";
            foreach ($data as $name)
            {
                $all .= $name['Design_Name'] . ", ";
            }
            $all = rtrim($all, ", ");
            return $all;
        }
        else
        {
            return false;
        }
    }
    public function get_sizes_by_comma($values)
    {
        $sql  = "SELECT * FROM `size` WHERE find_in_Set(`Size_Id`,'" . $values . "')";
        $data = $this->db->query($sql)->result_array();
        if (!empty($data))
        {
            $all = "";
            foreach ($data as $name)
            {
                $all .= $name['Size_Name'] . ", ";
            }
            $all = rtrim($all, ", ");
            return $all;
        }
        else
        {
            return false;
        }
    }

    public function check_lot_number($array)
    {
        if (is_array($array))
        {
            $i = 0;
            foreach ($array as $lot_no)
            {
                $sql = $this->db->where('Lot_Number', $lot_no)->get('lot_number');
                if ($sql->num_rows() > 0)
                {
                    $i = 1;
                }
            }
            if ($i == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    //Check Price LIst here
    public function check_price_list()
    {
        $input   = $this->input->post();
        $i       = 0;
        $designs = $input['Design_Id'];
        $where   = "Price_Id!=0  AND (";
        if (!empty($designs))
        {
            $where .= " ( ";
            foreach ($designs as $des)
            {
                $where .= " FIND_IN_SET('" . $des . "',Design_Id) OR";
            }
            $where = rtrim($where, "OR");
            $where .= ")";
        }
        $sizes = $input['Size_Id'];
        if (!empty($sizes))
        {
            $where .= "OR ( ";
            foreach ($sizes as $size)
            {
                $where .= " FIND_IN_SET('" . $size . "',Size_Id) OR";
            }
            $where = rtrim($where, "OR");
            $where .= ")";
        }
        $date = filter_date($input['Date']);
        $where .= " ) AND (FIND_IN_SET(Employee_Id,'" . implode(',', $input['Employee_Id']) . "') AND DATE(From_Date) >= '" . $date . "' ) AND Process_Id='" . $input['Process_Id'] . "' AND Item_Id='" . $input['Item_Id'] . "'";

        $sql   = "SELECT * FROM price_list WHERE " . $where;
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    //get Production quantity_here
    public function get_production_quantity($lot_number, $Process_Id)
    {
        $sql  = $this->db->select('*')->where(array('Lot_Number' => $lot_number, 'Process' => $Process_Id, 'Production_Type!=' => 'LG'))->get('productions');
        $sql3 = $this->db->select('*')->where(array('Lot_Number' => $lot_number, 'Process' => $Process_Id, 'Production_Type' => 'LG'))->get('productions');
        $this->db->last_query();
        $wastage           = @$this->db->select('SUM(`Disposal_Quantity`) as wastage')->where(array('Lot_Number' => $lot_number, 'Production_Type!=' => 'LG'))->get('productions')->row()->wastage;
        $starting_quantity = $this->db->select('Balance')->where(array('Lot_Number' => $lot_number, 'Production_Type' => 'LG'))->get('productions')->row()->Balance;
        if ($sql3->num_rows() > 0)
        {
            return 0;
        }
        if ($sql->num_rows() > 0)
        {
            $sql2     = $this->db->select('SUM(Done_Quantity) as Done_Quantity')->where(array('Lot_Number' => $lot_number, 'Process' => $Process_Id, 'Production_Type!=' => 'LG'))->get('productions');
            $data     = $sql2->row();
            $quantity = $starting_quantity - $wastage - $data->Done_Quantity;
            return $quantity;
        }
        else
        {
            $quantity = $starting_quantity - $wastage;
            return $quantity;
        }
    }

    // Manage Ladger Here
    public function insert_ladger($data)
    {
        $current_balace = @$this->db->query("SELECT Balance FROM ledger WHERE Employee='" . $data['Employee'] . "' ORDER BY Ledger_Id DESC LIMIT 1")->row()->Balance;
        if (empty($current_balace))
        {
            $current_balace = 0;
        }
        if ($data['Ladger_Action'] == 'credit')
        {
            $insert_data['Ladger_Action'] = 'credit';
            $rem_bal                      = $data['Amount'] + $current_balace;
        }
        else
        {
            $insert_data['Ladger_Action'] = 'debit';
            $rem_bal                      = $current_balace - $data['Amount'];
        }
        if (!empty($data['Production']))
        {
            $insert_data['Production'] = $data['Production'];
        }
        if (!empty($data['Lot_no']))
        {
            $insert_data['Lot_no'] = $data['Lot_no'];
        }
        if (!empty($data['Description']))
        {
            $insert_data['Description'] = $data['Description'];
        }
        if (!empty($data['Voucher']))
        {
            $insert_data['Voucher'] = $data['Voucher'];
        }
        if (!empty($data['Payment_Verify_Id']))
        {
            $insert_data['Payment_Verify_Id'] = $data['Payment_Verify_Id'];
        }
        if (!empty($data['Receipt_Id']))
        {
            $insert_data['Receipt_Id'] = $data['Receipt_Id'];
        }
        if (!empty($data['Transfer_Id']))
        {
            $insert_data['Transfer_Id'] = $data['Transfer_Id'];
        }
        $insert_data['Amount']       = $data['Amount'];
        $insert_data['Balance']      = $rem_bal;
        $insert_data['Employee']     = $data['Employee'];
        $insert_data['Date']         = $data['Date'];
        $insert_data['Created_Date'] = date('Y-m-d H:i:s');
        $insert_data['Date']         = $data['Date'];
        $insert_data['Company']      = $data['Company'];
        $insert_data['Financial']    = $data['Financial'];
        if ($this->insert_data('ledger', $insert_data))
        {
            $update_data['Balance'] = $rem_bal;
            if ($this->update_data('party', $update_data, array('Party_Id' => $data['Employee'])))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    //Get PRice of lot
    public function get_price($row, $row2, $date)
    {
        $where = "Price_Id!=0  AND  FIND_IN_SET('" . $row2['Design'] . "',Design_Id ) AND  FIND_IN_SET('" . $row2['Size'] . "',Size_Id) AND Company_Id='" . $row2['Company'] . "' AND Item_Id='" . $row2['Item_Id'] . "' AND Process_Id='" . $row['Process'] . "' AND Unit_Id='" . $row['Unit_Id'] . "' AND Employee_Id='" . $row['Employee_Id'] . "' AND DATE(From_Date)<='" . filter_date($date) . "'";
        $sql2  = $this->db->where($where)->order_by('Price_Id', 'desc')->get('price_list');
        if ($sql2->num_rows() > 0)
        {
            return $sql2->row()->Price_Value;
        }
        else
        {
            return 0;
        }
    }
    //Get PRice of lot
    public function get_price2($lot_id, $row, $date)
    {
        $sql = $this->db->select('ln.*,lni.Company')->from('lot_number_info lni')->join('lot_number ln', 'ln.info=lni.Info_Id', 'left')->where('ln.Lot_Number', $lot_id)->get();
        if ($sql->num_rows() > 0)
        {
            $row2  = $sql->row_array();
            $where = "Price_Id!=0  AND  FIND_IN_SET('" . $row2['Design'] . "',Design_Id ) AND  FIND_IN_SET('" . $row2['Size'] . "',Size_Id) AND Company_Id='" . $row2['Company'] . "' AND Item_Id='" . $row2['Item_Id'] . "' AND Process_Id='" . $row['Process'] . "' AND Unit_Id='" . $row['Unit_Id'] . "' AND Employee_Id='" . $row['Employee_Id'] . "' AND DATE(From_Date)<='" . filter_date($date) . "'";
            $sql2  = $this->db->where($where)->get('price_list');
            if ($sql2->num_rows() > 0)
            {
                return $sql2->row()->Price_Value;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            return 0;
        }
    }

    public function get_lot_details($Lot_info_id)
    {
        $query1 = $this->db->select('lni.*,supr.Party_Name as sup_name,mend.Party_Name as mend_name,comp.Company_Name')
            ->from('lot_number_info as lni')
            ->join('party as supr', 'supr.Party_Id = lni.Supervisor', 'left')
            ->join('party as mend', 'mend.Party_Id = lni.Mending_By', 'left')
            ->join('company as comp', 'comp.Company_Id = lni.Company', 'left')
            ->get();

        $query = $this->db->select('ln.*,p.Average,emp.Party_Name as emp_name,ps.Process_Name,d.Design_Name,s.Size_Name,c.Shade_Name,u.Unit_Name,im.Master_Name,p.Done_Quantity,p.Disposal_Quantity,p.Units')
            ->where('ln.info', $Lot_info_id)
            ->where('p.Production_Type', 'LG')
            ->from('lot_number as ln')

            ->join('productions as p', 'p.Lot_Number = ln.Lot_Number', 'left')
            ->join('party as emp', 'emp.Party_Id = p.Employee_Id', 'left')
            ->join('process as ps', 'ps.Process_Id = p.Process', 'left')
            ->join('design as d', 'd.Design_Id = ln.Design', 'left')
            ->join('item_master as im', 'im.Master_Id = ln.Item_Id', 'left')
            ->join('size as s', 's.Size_Id = ln.Size', 'left')
            ->join('units as u', 'u.unit_Id = p.Unit_Id', 'left')
            ->join('shade as c', 'c.Shade_Id = ln.Color', 'left')
            ->get();

        return array('info' => $query1->row_array(), 'lot' => $query->result_array(), 'ID' => $Lot_info_id);
    }

    public function select_where_in($table, $coulumn, $array_items)
    {
        $this->db->where_in($coulumn, $array_items);
        return $this->db->get($table)->result_array();
    }

    public function check_payment_entry($against_voucher)
    {
        $sql = "SELECT SUM(pv.Amount_Paid) as paid_amount,pe.Amount FROM `payment_verify` as pv
                JOIN payment_entry as pe ON pe.Voucher_Number=pv.Agianst_Voucher_Number
                WHERE pv.Agianst_Voucher_Number='" . $against_voucher . "'";
        /*$this->db->query($sql);*/

        /*return $this->db->query($sql)->row_array();*/
        if ($this->db->query($sql)->num_rows() <= 0)
        {
            return true;
        }
        else
        {
            $row = $this->db->query($sql)->row_array();
            if (!empty($row['paid_amount']) && !empty($row['Amount']))
            {   
                if ($row['paid_amount'] < $row['Amount'])
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }
    }

    //Fetch Bulk lot Detail here
    public function get_bulk_lot_detail($id)
    {
        return $this->db->select('bl.*,fp.Process_Name as From_Pro_Name,p.Process_Name as Pro_Name,c.Company_Name,emp.Party_Name as Employee_Name')
            ->from('bulk_lot bl')
            ->join('process fp', 'fp.Process_Id=bl.From_Process', 'left')
            ->join('process p', 'p.Process_Id=bl.Process', 'left')
            ->join('company c', 'c.Company_Id=bl.From_Company', 'left')
            ->join('party emp', 'emp.Party_Id=bl.Employee_Id', 'left')
            ->where('bl.Bulk_Id', $id)
            ->get()
            ->row_array();
    }

    //Fetch sub detail here
    public function get_bulk_sub_lot_detail($id)
    {
        return $this->db->select('p.*,l.Lot_Chain,d.Design_Name,s.Size_Name,sh.Shade_Name as Color_Name,im.Master_Name,u.Unit_Name')
            ->from('productions p')
            ->join('lot_number l', 'l.Lot_Number=p.Lot_Number', 'left')
            ->join('design d', 'd.Design_Id=l.Design', 'left')
            ->join('size s', 's.Size_Id=l.Size', 'left')
            ->join('shade sh', 'sh.Shade_Id=l.Color', 'left')
            ->join('item_master im', 'im.Master_Id=p.Item_Id', 'left')
            ->join('units u', 'u.Unit_Id=p.Unit_Id', 'left')
            ->where(array('p.Chalan' => $id, 'Production_Type' => 'BULK'))
            ->get()
            ->result_array();
    }

    //Payment Verify Update here
    public function update_payment_veirfy($input, $record, $alreday_paid)
    {
        if ($input['Amount_Paid'] == $record['Amount_Paid'])
        {
            $this->db->where('Payment_Verify_Id', $input['Pv_Id'])
                ->set('Description', $input['Description'])
                ->update('ledger');

            $this->db->where('Pv_Id', $input['Pv_Id'])
                ->set('Description', $input['Description'])
                ->update('payment_verify');
            return true;
        }
        else
        {
            $Bal_plus    = $record['Amount_Paid'] - $input['Amount_Paid'];
            $Amount_plus = $input['Amount_Paid'] - $record['Amount_Paid'];
            //From OR Debit Employee Code Start here
            $get_from_ledger_rcord = $this->get_data('ledger', array('Payment_Verify_Id' => $input['Pv_Id'], 'Employee' => $record['Employee_ID']), 'single');
            $this->db->where('Ledger_Id', $get_from_ledger_rcord['Ledger_Id'])
                ->set('Amount', 'Amount+' . $Amount_plus, false)
                ->set('Description', $input['Description'])
                ->set('Balance', 'Balance+' . $Bal_plus, false)
                ->update('ledger');
            $this->db->where(array('Ledger_Id>' => $get_from_ledger_rcord['Ledger_Id'], 'Employee' => $record['Employee_ID']))
                ->set('Balance', 'Balance+' . $Bal_plus, false)
                ->update('ledger');
            //Update Original Record
            $this->db->where('Pv_Id', $input['Pv_Id'])
                ->set('Description', $input['Description'])
                ->set('Amount_Paid', $input['Amount_Paid'])
                ->update('payment_verify');
            return true;
        }
    }

    //Transfer Entry here
    public function update_transfer_entry($transfer = array())
    {
        if (!empty($transfer))
        {
            $records = $this->get_data('transfer_entry', array('Te_Id' => $transfer['Te_Id']), 'single');
            if ($records['Amount'] == $transfer['Amount'])
            {
                $this->db->where('Transfer_Id', $transfer['Te_Id'])
                    ->set('Description', $transfer['Description'])
                    ->update('ledger');

                $this->db->where('Te_Id', $transfer['Te_Id'])
                    ->set('Description', $transfer['Description'])
                    ->update('transfer_entry');
                return true;
            }
            else
            {
                $Bal_plus    = $records['Amount'] - $transfer['Amount'];
                $Amount_plus = $transfer['Amount'] - $records['Amount'];
                //From OR Debit Employee Code Start here
                $get_from_ledger_rcord = $this->get_data('ledger', array('Transfer_Id' => $transfer['Te_Id'], 'Employee' => $records['From_Employee_ID']), 'single');
                $this->db->where('Ledger_Id', $get_from_ledger_rcord['Ledger_Id'])
                    ->set('Amount', 'Amount+' . $Amount_plus, false)
                    ->set('Description', $transfer['Description'])
                    ->set('Balance', 'Balance+' . $Bal_plus, false)
                    ->update('ledger');
                $this->db->where(array('Ledger_Id>' => $get_from_ledger_rcord['Ledger_Id'], 'Employee' => $records['From_Employee_ID']))
                    ->set('Balance', 'Balance+' . $Bal_plus, false)
                    ->update('ledger');

                //From Or Debit Employee Code End here

                //To Or Credit Entry Employee Code Start here
                $get_to_ledger_rcord = $this->get_data('ledger', array('Transfer_Id' => $transfer['Te_Id'], 'Employee' => $records['To_Employee_ID']), 'single');

                $this->db->where('Ledger_Id', $get_to_ledger_rcord['Ledger_Id'])
                    ->set('Amount', 'Amount+' . $Amount_plus, false)
                    ->set('Description', $transfer['Description'])
                    ->set('Balance', 'Balance+' . $Amount_plus, false)
                    ->update('ledger');
                $this->db->where(array('Ledger_Id>' => $get_to_ledger_rcord['Ledger_Id'], 'Employee' => $get_to_ledger_rcord['Employee']))
                    ->set('Balance', 'Balance+' . $Amount_plus, false)
                    ->update('ledger');

                //To Or Credit Entry Employee  End here

                //Transfer Entrty Update here
                $this->db->where('Te_Id', $transfer['Te_Id'])
                    ->set('Amount', 'Amount+' . $Amount_plus, false)
                    ->set('Description', $transfer['Description'])
                    ->update('transfer_entry');
                return true;
            }
        }
        else
        {
            return false;
        }
    }
}
