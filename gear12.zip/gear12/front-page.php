<?php get_header(); ?>
<?php global $post; ?>

<div class="gear-homepage">
	<div class="gear-container">
		<?php while ( have_posts() ) : the_post();
			the_content();
		endwhile; ?>
	</div>

	<div class="gear-services">
		<div class="gear-container">
			<?php
				$args = array(
					'post_type'      => 'service',
					'post_status' 	 => 'publish',
					'posts_per_page' => 3,
					'order' 		 => 'DESC',
				);
				$gear_query = null;
				$gear_query = new WP_Query($args);
				if( $gear_query->have_posts() ) {
					$counter = 1;
					while( $gear_query->have_posts() ) : $gear_query->the_post();
						if( $counter % 2 == 0 ) {
							$gear_left = 'gear-right text-right'; $gear_rite = 'gear-left'; 
						} else {
							$gear_left = 'gear-left'; $gear_rite = 'gear-right'; 
						}
						$image_id  = get_post_thumbnail_id();
	                	$image_url = wp_get_attachment_image_src($image_id,'large', true);
	                	$icon_url  = get_field( 'service_icon', $post->id, true ); ?>
						<div class="service-grid">
							<div class="sg-common <?php echo $gear_left; ?>">
	                			<figure class="service-img"><img src="<?php echo $image_url[0]; ?>"></figure>
							</div>
							<div class="sg-common <?php echo $gear_rite; ?>">
								<article>
									<div class="text-center"><img src="<?php echo $icon_url['url']; ?>" class="service-ico"></div>
									<h2><?php the_title(); ?></h2>
									<p><?php echo wp_trim_words( get_the_content(), '15', ''); ?></p>
									<div><a href="<?php the_permalink(); ?>">Learn More</a></div>
								</article>
							</div>
						</div>
					<?php $counter++; endwhile;
				}
				wp_reset_query();
			?>
		</div>
	</div>

	<div class="gear-clients">
		<div class="gear-container clearfix">
			<h2 class="text-center">Current Clients</h2>
			<ul class="client-current text-center">
				<?php
					$args = array(
						'post_type'      => 'client',
						'post_status' 	 => 'publish',
						'posts_per_page' => -1,
						'order' 		 => 'DESC',
						'tax_query' => array(
						    array(
						        'taxonomy' => 'client-cat',
						        'terms' => 'current-clients',
						        'field' => 'slug'
						    )
						),
					);
					$gear_query = null;
					$gear_query = new WP_Query($args);
					if( $gear_query->have_posts() ) {
						$counter = 1;
						while( $gear_query->have_posts() ) : $gear_query->the_post();
							$client_url = get_field( 'client_link', $post->id, true );
							$image_id  = get_post_thumbnail_id();
	                		$image_url = wp_get_attachment_image_src($image_id,'large', true);
							if( $client_url ) { ?>
								<li><a href="<?php echo $client_url; ?>"><img src="<?php echo $image_url[0]; ?>"></a></li>
							<?php } else { ?>
								<li><img src="<?php echo $image_url[0]; ?>"></li>
							<?php }
						$counter++; endwhile;
					}
					wp_reset_query();
				?>
			</ul>
		</div>

		<div class="gear-container clearfix">
			<h2 class="text-center">Past Clients</h2>
			<?php
	      		$custom_cat = array(
	      			'taxonomy'=>'client-cat',
	      			'orderby' => 'title',
	      			'order'   => 'ASC'
	      		);
	      		$categories = get_categories( $custom_cat );
	      		foreach( $categories as $cat ): ?>
	      			<ul class="categories-listing <?php echo $cat->slug; ?> text-center">
	      				<li class="cc-name"><?php echo $cat->name; ?></li>
	      				<?php $args = array(
	      					'post_type' => 'client',
	      					'tax_query' => array(
	      						array(
	      							'taxonomy' => 'client-cat',
	      							'field'    => 'slug',
	      							'terms'    => $cat->slug,
	      						),
	      					),
	      				);
		      			$my_query = null;
		      			$my_query = new WP_Query($args);
		      			while ($my_query->have_posts()) : $my_query->the_post();
		      				$client_link = get_field( 'client_link', $post->id, true );
		      				if( $client_link ) { ?>
		      					<li><a href="<?php echo $client_link; ?>"><?php echo $post->post_title; ?></a></li>
		      				<?php } else { ?>
		      					<li><?php echo $post->post_title; ?></li>
		      				<?php }
		      			endwhile;
		            	wp_reset_query(); ?>
		            </ul>
				<?php endforeach;
			?>
		</div>
	</div>
</div>

<?php get_footer(); ?>