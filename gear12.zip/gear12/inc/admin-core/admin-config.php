<?php
	add_filter( 'redux-backup-description', 'admin_change_default_texts' );
	function admin_change_default_texts() {
		return __('You can copy/download your current options settings. This is a backup solution in case anything goes wrong.', 'gear');
	}

	// ReduxFramework Config
	$args = array();
	$tabs = array();

	// Default: true
	$args['dev_mode'] = false;

	// Set a custom option name
	$args['opt_name'] = 'gear_options';

	// Theme Panel Main Display Name
	$args['display_name'] 	 = __(' Gear Options Panel','gear');
	$args['display_version'] = false;

	// If you want to use Google Webfonts, you MUST define the api key.
	$args['google_api_key']  = 'AIzaSyCDsXSCHtSvzvF-y477pMU2JMDDrOFeino';

	// Define the starting tab for the option panel.
	$args['last_tab'] = '0';

	// Default: 'standard'
	$args['admin_stylesheet'] = 'standard';

	// Default: null
	$args['import_icon_class'] = 'el-icon-large';

	// Set a custom menu icon.
	$args['menu_icon']  = get_template_directory_uri() .'/images/favicon.png';

	// Set a custom title for the options page.
	$args['menu_title'] = __('Gear Options', 'gear');

	// Set a custom page title for the options page.
	$args['page_title'] = __('Gear Options', 'gear');

	// Set a custom page slug for options page
	$args['page_slug']  = 'gear_options';

	// Show Default
	$args['default_show'] = false;

	// Default Mark
	$args['default_mark'] = '';

	// Declare sections array
	$sections = array();

	// Header Settings
	$sections[] = array(
		'title'      => __('Header Settings', 'gear'),
		'header'     => __('Welcome to the Gear Options Framework', 'gear'),
		'icon_class' => 'el-icon-large',
		'icon'       => 'el-icon-cogs',
		'submenu'    => true,
		'fields'     => array(
			array(
				'id'       => 'logo',
				'url'      => true,
				'type'     => 'media',
				'title'    => __('Primary Logo', 'gear'),
				'default'  => array( 'url' => get_template_directory_uri() .'/images/logo.png' ),
				'subtitle' => __('Upload Logo (Width X Height : 320 x 75)', 'gear'),
			),
			array(
				'id'       => 'favicon',
				'url'      => true,
				'type'     => 'media', 
				'title'    => __('Your Favicon', 'gear'),
				'default'  => array( 'url' => get_template_directory_uri() .'/images/favicon.png' ),
				'subtitle' => __('Favicon Icon (png or ico - Max size: 1MB)', 'gear'),
			)
	    ),
	);

	// Get in Touch Options
	$sections[] = array(
		'title'      => __('Get in Touch', 'gear'),
		'header'     => __('Welcome to the Gear Options Framework', 'gear'),
		'icon_class' => 'el-icon-large',
		'icon'       => 'el-icon-inbox',
		'submenu'    => true,
		'fields'     => array(
			array(
				'id'       => 'git_color',
				'type'     => 'color',
				'title'    => __('Get in Touch Background Color', 'gear'),
				'default'  => '#1f6e8f'
			),
			array(
				'id'       => 'git_text',
				'type'     => 'text',
				'title'    => __('Ready to grow your brand? Text', 'gear'),
				'default'  => __('Ready to grow your brand?', 'gear'),
			),
			array(
				'id'       => 'git_btn',
				'type'     => 'text',
				'title'    => __('Button Text', 'gear'),
				'default'  => __('Get in Touch', 'gear'),
			),
			array(
				'id'       => 'git_link',
				'type'     => 'text',
				'title'    => __('Link this Button to?', 'gear'),
				'default'  => __('http://localhost/gear/contact', 'gear'),
			)
		),
	);

	// Footer Settings
	$sections[] = array(
		'title'      => __('Footer', 'gear'),
		'header'     => __('Welcome to the Gear Options Framework', 'gear'),
		'icon_class' => 'el-icon-large',
		'icon'       => 'el-icon-cogs',
		'submenu'    => true,
		'fields'    => array(
			array(
				'id'    => 'footer_columns',
				'type'  => 'editor', 
				'title' => __('Footer Column Content', 'gear'),
			),
			array(
				'id'    => 'footer_copyright',
				'type'  => 'editor', 
				'title' => __('Footer Copyright text', 'gear'),
			)
		)
	);

	// Social Network
	$sections[] = array(
	    'title'      => __('Social Networks', 'gear'),
		'submenu'    => true,
		'icon'       => 'el-icon-twitter',
		'icon_class' => 'el-icon-large',
		'fields'     => array(
			array(
				'id'       => 'facebook',
				'type'     => 'text',
				'title'    => __('Facebook', 'gear'),
				'subtitle' => __('Insert your Facebook URL here.', 'gear'),
			),
			array(
				'id'       => 'twitter',
				'type'     => 'text',
				'title'    => __('Twitter', 'gear'),
				'subtitle' => __('Insert your Twitter URL here.', 'gear'),
			),
			array(
				'id'       => 'instagram',
				'type'     => 'text',
				'title'    => __('Instagram', 'gear'),
				'subtitle' => __('Insert your Instagram URL here.', 'gear'),
			)
		)
	);

	// Shortcode Options
	$sections[] = array(
	    'title'      => __('Global Settings', 'gear'),
		'submenu'    => true,
		'icon'       => 'el-icon-wrench',
		'icon_class' => 'el-icon-large',
		'fields'     => array(
			array(
				'id'       => 'news_pagination',
				'type'     => 'select',
				'title'    => __('In the News', 'gear'),
				'subtitle' => __('Pagination: Posts per Page', 'gear'),
				'options'  => array(
			        '4'  => '4 Posts per page',
			        '5'  => '5 Posts per page',
			        '6'  => '6 Posts per page',
			        '7'  => '7 Posts per page',
			        '8'  => '8 Posts per page',
			        '9'  => '9 Posts per page',
			        '10' => '10 Posts per page',
			        '-1' => 'No Pagination'
			    ),
			    'default'  => '-1',
			)
		)
	);

	global $ReduxFramework;
	$ReduxFramework = new ReduxFramework($sections, $args, $tabs);

	// Function used to retrieve theme option values
	if ( ! function_exists('gear_options') ) {
		function gear_options($id, $fallback = false, $param = false ) {
			global $gear_options;
			if ( $fallback == false ) $fallback = '';
			$output = ( isset($gear_options[$id]) && $gear_options[$id] !== '' ) ? $gear_options[$id] : $fallback;
			if ( !empty($gear_options[$id]) && $param ) {
				$output = $gear_options[$id][$param];
			}
			return $output;
		}
	}
?>