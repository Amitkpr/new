 <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-user bg-yellow"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                <p>New phone +1(800)555-1234</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                <p>nora@example.com</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-file-code-o bg-green"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                <p>Execution time 5 seconds</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="label label-danger pull-right">70%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Update Resume
                <span class="label label-success pull-right">95%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-success" style="width: 95%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Laravel Integration
                <span class="label label-warning pull-right">50%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Back End Framework
                <span class="label label-primary pull-right">68%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Some information about this general settings option
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Allow mail redirect
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Other sets of options are available
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Expose author name in posts
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Allow the user to show his name in blog posts
            </p>
          </div>
          <!-- /.form-group -->

          <h3 class="control-sidebar-heading">Chat Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Show me as online
              <input type="checkbox" class="pull-right" checked>
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Turn off notifications
              <input type="checkbox" class="pull-right">
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Delete chat history
              <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
            </label>
          </div>
          <!-- /.form-group -->
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/bower_components/select2/dist/js/select2.full.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/raphael/raphael.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/bower_components/morris.js/morris.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/jquery-knob/dist/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/moment/min/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url(); ?>assets/admin/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/demo.js"></script>
<script>

  /*table for sites */
   $(function () {
    $('#all_sites').DataTable();
   /*  $('#all_sites').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : true
    }) */
	
    //Initialize Select2 Elements
    $('.select2').select2();
  })

</script>
	<script>
	$('#machine_name').blur(function() {
		var value = $(this).val();
		value = value.toLowerCase();
		var slug = value.replace(/\s/g,'');
		$('#machine_slug').val(slug);
	});
  
	//Date picker
	/* $('.date .input-group-addon').click(function(){
		
	}); */
	$('.common_date_picker').datepicker({
		autoclose: true,
	});
	
	$('.common_date_month_picker').datepicker({
		format: "M-yyyy",
		viewMode: "months", 
		minViewMode: "months"
	});
	
	 
		
    $('#datepicker').datepicker({
		autoclose: true,
		format: 'dd/mm/yyyy'
	});
	
	/* { dateFormat: 'dd-mm-yy', changeYear: true} */
	
	/* $( "#datepicker" ).datepicker({ defaultDate: new Date() }); */
	
	$("#datepicker").datepicker().datepicker("setDate", new Date());
	$('.date .input-group-addon').click(function (e) {
        $('#datepicker').datepicker("show");
        e.preventDefault();
    });
	
  /*on change select value	*/
	$(document).ready(function(){
		$('#site_id').change(function(){
			var value = $(this).val();
			if(value > 0){
				$('#cat_id').attr('disabled',false);
			}else{
				$('#cat_id').attr('disabled',true);
				
				$('#v_no').attr('disabled',true);
				$('#d_no').attr('disabled',true);
				$('#m_no').attr('disabled',true);
				
				$('#cat_id').val('0');
				
				$('#v_no').val('');
				$('#d_no').val('');
				$('#m_no').val('');
			}
		});
		$('#cat_id').change(function(){
			var value = $(this).val();
			var option = $('option:selected', this).attr('rel');
			if(option == 'dno'){
				$('#m_no_wrap').hide();
				$('#d_no_wrap').show();
			}else if(option == 'mno'){
				$('#m_no_wrap').show();
				$('#d_no_wrap').hide();
			}else{
				$('#m_no_wrap').hide();
				$('#d_no_wrap').hide();
			}
			
			if(value > 0){
				$('#v_no').attr('disabled',false);
				$('#d_no').attr('disabled',false);
				$('#m_no').attr('disabled',false);
			}else{
				$('#v_no').attr('disabled',true);
				$('#d_no').attr('disabled',true);
				$('#m_no').attr('disabled',true);
				
				$('#v_no').val('');
				$('#d_no').val('');
				$('#m_no').val('');
			}
		});
		
		
		/*calculations*/
		$('.a').blur(function() {
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var b = $(tr).find('.b').val();
			var a = $(tr).find('.a').val();
			var c = $(tr).find('.c').val();
			var d = parseInt(a)+parseInt(b)+parseInt(c);
			if(c == ''){
				$(tr).find('.td').val('');	
			}else{
				$(tr).find('.td').val(d);
			}
		});
		$('.b').blur(function() {
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var b = $(tr).find('.b').val();
			var a = $(tr).find('.a').val();
			var c = $(tr).find('.c').val();
			var d = parseInt(a)+parseInt(b)+parseInt(c);
			/* $(tr).find('.td').val(d); */
			if(c == ''){
				$(tr).find('.td').val('');	
			}else{
				$(tr).find('.td').val(d);
			}
		});
		$('.c').blur(function() {
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var b = $(tr).find('.b').val();
			var a = $(tr).find('.a').val();
			var c = $(tr).find('.c').val();
			var d = parseInt(a)+parseInt(b)+parseInt(c);
			/* $(tr).find('.td').val(d); */
			if(c == ''){
				$(tr).find('.td').val('');	
			}else{
				$(tr).find('.td').val(d);
			}
		});
		
		/*===============================*/
		/* count previous KMR */
		$('.td').blur(function() {
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var hsd = $(tr).find('.hsd').val();
			var td = $(tr).find('.td').val();
			/* alert(avgtrip); */
			var d = parseInt(hsd)/parseInt(td);
			/* $(tr).find('.kmrrc').val(d); */
			if(hsd == ''){
				$(tr).find('.avgtrip').val('');	
			}else{
				$(tr).find('.avgtrip').val(d.toFixed(2));
			}
		});
		
		$('.hsd').blur(function() {
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var hsd = $(tr).find('.hsd').val();
			var td = $(tr).find('.td').val();
			/* alert(avgtrip); */
			var d = parseInt(hsd)/parseInt(td);
			/* $(tr).find('.kmrrc').val(d); */
			if(hsd == ''){
				$(tr).find('.avgtrip').val('');	
			}else{
				$(tr).find('.avgtrip').val(d.toFixed(2));
			}
		});
		
		
		$('.kmrrc').blur(function() {
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var kmrrc = $(tr).find('.kmrrc').val();
			var kmrnew = $(tr).find('.kmrnew').val();
			/* alert(avgtrip); */
			var total = parseInt(kmrrc)-parseInt(kmrnew);
			/* $(tr).find('.kmrrc').val(d); */
			if(kmrnew == ''){
				$(tr).find('.total').val('');	
			}else{
				$(tr).find('.total').val(total.toFixed(2));
			}
		});
		
		$('.kmrnew').blur(function() {
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var kmrrc = $(tr).find('.kmrrc').val();
			var kmrnew = $(tr).find('.kmrnew').val();
			/* alert(avgtrip); */
			var total = parseInt(kmrnew)-parseInt(kmrrc);
			/* $(tr).find('.kmrrc').val(d); */
			/* get total value*/
			if(kmrnew == ''){
				$(tr).find('.total').val('');	
			}else{
				$(tr).find('.total').val(total);
			}
			
			/*get average*/
			var hsd = $(tr).find('.hsd').val();
			var avg = parseInt(total)/parseInt(hsd);
			$(tr).find('.average').val(avg.toFixed(2));	
			
			/*get lead*/
			var td = $(tr).find('.td').val();
			var lead = (parseInt(total)/parseInt(td))/2;
			$(tr).find('.lead').val(lead.toFixed(2));	
			
		});
		
		/* $('.kmrnew').blur(function() {
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var hsd = $(tr).find('.hsd').val();
			var total = $(tr).find('.total').val();
			var average = parseInt(kmrnew)/parseInt(total);
			if(total == ''){
				$(tr).find('.average').val('');	
			}else{
				$(tr).find('.average').val(average.toFixed(2));
			}
		}); */
		
		/* $('.kmrnew').blur(function() {
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var td = $(tr).find('.td').val();
			var total = $(tr).find('.total').val();			
			var lead = (parseInt(td)/parseInt(total))/2;
			if(total == ''){
				$(tr).find('.lead').val('');	
			}else{
				$(tr).find('.lead').val(lead.toFixed(2));
			}
		}); */
		
		
		number_validation('.a, .b, .c, .td, .hsd, .avgtrip, .kmrrc, .kmrnew, .total, .average, .lead');
		
		/*function for numeric validations*/
		function number_validation(newClass){		
			$(newClass).keydown(function (e) {
			// Allow: backspace, delete, tab, escape, enter and .
				if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
					 // Allow: Ctrl+A, Command+A
					(e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
					 // Allow: home, end, left, right, down, up
					(e.keyCode >= 35 && e.keyCode <= 40)) {
						 // let it happen, don't do anything
						 return;
				}
				// Ensure that it is a number and stop the keypress
				if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
					e.preventDefault();
				}
			});
		}
		/*ajax to save calculations for summery*/
		$(document).on('click','.customBtn',function(){
			var parent = $(this).parent();
			var tr = $(parent).parent();
			$(tr).find('.data_loader').show();
			$(tr).find('.customBtn').hide();
			var parent = $(this).parent();
			var tr = $(parent).parent();
			var machine_id = tr.find('.machine_id').val();
			var a = tr.find('.a').val();
			var b = tr.find('.b').val();
			var c = tr.find('.c').val();
			var td = tr.find('.td').val();
			/* alert(td); */
			var hsd = tr.find('.hsd').val();
			var avgtrip = tr.find('.avgtrip').val();
			var kmrrc = tr.find('.kmrrc').val();
			var kmrnew = tr.find('.kmrnew').val();
			var average = tr.find('.average').val();
			var total = tr.find('.total').val();
			var lead = tr.find('.lead').val();
			var strc = 'machine_id='+machine_id+'&a='+a+'&b='+b+'&c='+c+'&td='+td+'&hsd='+hsd+'&avgtrip='+avgtrip+'&kmrrc='+kmrrc+'&kmrnew='+kmrnew+'&average='+average+'&total='+total+'&lead='+lead;

			$.ajax({  
				context: this,      
				url: "<?php echo base_url();?>admin/dashboard/vehicle",
				type: 'POST',             
				data: strc,
				success: function(response) {
					/* alert(response); */
					$(tr).find('.data_loader').hide();
					$(tr).find('.customBtn').show();
				}           
			});
		});
		
		
		
		/*ajax to save insurance details for machines*/
		$(document).on('click','.update_machine',function(){
			var parent = $(this).parent();
			var tr = $(parent).parent();
			$(tr).find('.data_loader').show();
			$(tr).find('.customBtn').hide();
			var machine_details_id = $(this).attr('rel');
			
			var pur_model = tr.find('.pur_model').val();
			var tax = tr.find('.tax').val();
			var fitness = tr.find('.fitness').val();
			var permit = tr.find('.permit').val();
			/* alert(td); */
			var insurance = tr.find('.insurance').val();
			var insurer = tr.find('.insurer').val();
			var finance = tr.find('.finance').val();
			
			var strc = 'edit=true&id='+machine_details_id+'&pur_model='+pur_model+'&tax='+tax+'&fitness='+fitness+'&permit='+permit+'&insurance='+insurance+'&insurer='+insurer+'&finance='+finance;
			/* alert(strc); */
			$.ajax({  
				context: this,      
				url: "<?php echo base_url();?>admin/dashboard/addvehicledetails",
				type: 'POST',             
				data: strc,
				beforeSend: function(){
					/* // Handle the beforeSend event */
					$(tr).find('.update_machine').hide();
					$(tr).find('.loadericon').show();
				},
				success: function(response) {
					/* alert(response); */
					setTimeout(function(){ 
						$(tr).find('.loadericon').hide();
						$(tr).find('.update_machine').fadeIn( "slow" );
					}, 2000);
					
					/* setTimeout(function(){  */
						/* $(tr).find('.custom_check').hide( "slow" ); */
					/* 	$(tr).find('.update_machine').fadeIn( "slow" );
					}, 4000); */
					/* $( ".custom_check" ).fadeOut( "slow", function() {
						$(tr).find('.update_machine').show();
					}); */
					
					/* setTimeout(function(){ 
						$(tr).find('.custom_check').show();
						$(tr).find('.update_machine').show();
					}, 3000); */
				},
				complete: function(){
					/* // Handle the complete event */
					/* setTimeout(function(){ 
						$(tr).find('.custom_check').show();
						$(tr).find('.update_machine').show();
					}, 2000); */
				}				
			});
		});
		
		/*password field blank*/
		$('#password, #confirm_password').val('');		
	});
	
	$(document).ready(function(){
		/*machine single page*/
		$('.dateInput').datepicker({
			autoclose: true,
		});	
	});
</script>
</body>
</html>