<?php 

$errorsData = $this->session->flashdata('errorsData');
$message = $this->session->flashdata('message');
$sitenameDatas = $sitenamesData;
/* pt($sitenameDatas);
die; */

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
		<h1>Add User Here</h1>
		<!-- general form elements -->
		<div class="col-lg-5">  
		<div class="box box-primary">
			<div class="box-header with-border">
			  <h3 class="box-title">User Data</h3>
			</div>
			<div style="padding:0px 15px;">
			<!-- /.box-header -->
			<?php
				if(isset($message['message']) && $message['check'] == 'f'){ ?>
				<div class="alert alert-danger">
				 <?php echo $message['message']; ?>
				</div>
			<?php }
			
			if(isset($message['message']) && $message['check'] == 't'){ ?>
			<div class="alert alert-success">
			  <?php echo $message['message']; ?>
			</div>
			<?php } ?>
			</div>
			<!-- form start -->
			<?php
			
			/* if(!empty($editUser)){
				pt($editUser);
			} */
				
			?>
			<form method="POST" autocomplete="off" action="<?php echo base_url(); ?>admin/dashboard/adduser" role="form">
				<?php 
					if(!empty($editUser)){
						echo '<input type="hidden" value="true" name="edit">';
						echo '<input type="hidden" value="'.$editUser[0]->id.'" name="id">';
					}
				?>
				
				<div class="box-body">
					<div class="form-group">
					  <label for="name">Name</label>
					  <input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?php echo(isset($editUser[0]->name))?$editUser[0]->name:''; ?>">
					</div>
					 <div class="form-group">
						<label>Site Names</label>
						<select class="form-control select2" style="width: 100%;" name="site_id">
							<option>Select Site Name</option>
							<?php 
							
							foreach($sitenameDatas as $sitename){ 
								$id = $sitename->id;
								$name = $sitename->name;
							?>
							  <option value="<?php echo $id; ?>" <?php echo(isset($editUser[0]->site_id) && $editUser[0]->site_id == $id)?'selected="selected"':''; ?> ><?php echo $name; ?></option>
							<?php 
							} 
							?>
						</select>
					  </div>
					<div class="form-group">
					  <label for="role">Role</label>
					  <input type="test" class="form-control" name="role" id="role" placeholder="Role" readonly value="<?php echo(isset($editUser[0]->role))?$editUser[0]->role:''; ?>">
					</div>
					<div class="form-group">
					  <label for="email">Email</label>
					  <input type="email" class="form-control" name="email"  <?php echo(isset($editUser[0]->email))?'readonly':''; ?> id="email" placeholder="Email" value="<?php echo(isset($editUser[0]->email))?$editUser[0]->email:''; ?>">
					</div>
					<div class="form-group">
					  <label for="password">Password</label>
					  <input type="password" class="form-control" name="password" id="password" placeholder="Password" value="">
					</div>
					<div class="form-group">
					  <label for="confirm_password">Confirm Password</label>
					  <input type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm Password" value="">
					  <?php
						if($errorsData){
							echo '<label style="color:red;">'.$errorsData.'</label>';
						}
					  ?>
					</div>
				</div>
			  <!-- /.box-body -->

			  <div class="box-footer">
				<?php if(!empty($editUser)){ ?>
					<button type="submit" class="btn btn-primary">Update</button>
				<?php }else{ ?>
					<button type="submit" class="btn btn-primary">Submit</button>	
				<?php } ?>
			  </div>
			</form>
		</div>
		</div>
          <!-- /.box -->
		<div class="col-lg-7">  
		  <div class="box">
            <div class="box-header">
              <h3 class="box-title">All Users</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="all_sites" class="table table-bordered table-hover">
                <thead>
                <tr>
					<th>Sr. No</th>
					<th>User Names</th>
					<th>Email</th>
					<th>Site Name</th>
					<th>Role</th>
					<th>Edit</th>
					<th>Delete</th>
                </tr>
                </thead>
                <tbody>
				<?php 
				
				$countSiteNames = 1;
				foreach($result as $resultList){
					$id = $resultList->id;
					$siteName = $this->common_model->get_data_by_id('id','mines_sites',$resultList->site_id);
					$name = $resultList->name;
					$email = $resultList->email;
					$role = $resultList->role;
				?>
                <tr>
					<td><?php echo $countSiteNames; ?></td>
					<td><?php echo $name; ?></td>
					<td><?php echo $email; ?></th>
					<td><?php echo $siteName; ?></th>
					<td><?php echo $role; ?></td>
					<td style="text-align: center;"><a href="<?php echo base_url(); ?>admin/dashboard/adduser/?edit=true&id=<?php echo $id; ?>"><i class="fa fa-edit"></i></a></td>
					<td style="text-align: center;"><a href="<?php echo base_url(); ?>admin/dashboard/adduser/?delete=true&id=<?php echo $id; ?>"><i class="fa fa-trash"></i></a></td>
                </tr>
				<?php $countSiteNames++; } ?>
                </tbody>
                <tfoot>
                <tr>
					<th>Sr. No</th>
					<th>Site Name</th>
					<th>By User</th>
					<th>Created Date</th>
					<th>Updated Date</th>
					<th>Edit</th>
					<th>Delete</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
		</div>
          <!-- /.box -->
</section>
    <!-- /.content -->

  </div>
  
