<?php 
$message = $this->session->flashdata('message');
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Main content -->
    <section class="content">
		<h1>Add site name here</h1>
		<!-- general form elements -->
		<div class="box box-primary">
			<div class="box-header with-border">
			  <h3 class="box-title">Quick Example</h3>
			</div>
			<div style="padding:0px 15px;">
			<!-- /.box-header -->
			<?php
				if(isset($message['message']) && $message['check'] == 'f'){ ?>
				<div class="alert alert-danger">
				 <?php echo $message['message']; ?>
				</div>
			<?php }
			
			if(isset($message['message']) && $message['check'] == 't'){ ?>
			<div class="alert alert-success">
			  <?php echo $message['message']; ?>
			</div>
			<?php } ?>
			</div>
			<!-- form start -->
			<form method="POST" action="<?php echo base_url(); ?>admin/dashboard/addsite" role="form">
			  <div class="box-body">
				<div class="form-group">
				  <label for="site_name">Site Name</label>
				  <input type="text" class="form-control" name="site_name" id="site_name" placeholder="Site name">
				</div>
			
			  </div>
			  <!-- /.box-body -->

			  <div class="box-footer">
				<button type="submit" class="btn btn-primary">Submit</button>
			  </div>
			</form>
		</div>
          <!-- /.box -->
		  
		  <div class="box">
            <div class="box-header">
              <h3 class="box-title">Hover Data Table</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="all_sites" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>Sr. No</th>
                  <th>Site Name</th>
                  <th>By User</th>
                  <th>Created Date</th>
                  <th>Updated Date</th>
                </tr>
                </thead>
                <tbody>
				<?php 
				$countSiteNames = 1;
				foreach($result as $resultList){
				?>
                <tr>
                   <td><?php echo $countSiteNames; ?></td>
					<td><?php echo $resultList->name; ?></td>
					<td>Admin</th>
					<td><?php echo $resultList->created_date; ?></td>
					<td><?php echo $resultList->modified_date; ?></td>
                </tr>
				<?php $countSiteNames++; } ?>
                </tbody>
                <tfoot>
                <tr>
                   <th>Sr. No</th>
                  <th>Site Name</th>
                  <th>By User</th>
                  <th>Created Date</th>
                  <th>Updated Date</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
</section>
    <!-- /.content -->

  </div>
  
