<?php 

$errorsData = $this->session->flashdata('errorsData');
$message = $this->session->flashdata('message');
$categoryNameDatas = $categoryNameData;
$machinesDataResult = $machines_data;
if(!empty($selected_data)){
	$selected_data = $selected_data;	
}
$role = $userdetails[0]['role'];

?>
<style>
@import url('https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
/*.obtrips {
    position: absolute;
    top: 0;
    width: 286px;
    border: 1px solid #7accc8;
    height: 42px;
    left: 0;
    background: #7accc8;
    z-index: 2;
    color: #404849;
    line-height: 38px;
	font-family: 'Montserrat', sans-serif;
}*/
#all_sites tr:hover input{
	background-color: #f5f5f5;	
}
.tippers_data{
	background: transparent;
	box-shadow:inherit;
	border-top:inherit;
}
.tippers_data .table-bordered>thead>tr>th, .tippers_data  .table-bordered>thead>tr>td {
    border-bottom-width: 0px;
	border-color:#e6e6ec;
}
.tippers_data .table-bordered>thead>tr>th, .tippers_data  .table-bordered>tbody>tr>th, .tippers_data  .table-bordered>tfoot>tr>th, .tippers_data  .table-bordered>thead>tr>td, .tippers_data  .table-bordered>tbody>tr>td, .tippers_data  .table-bordered>tfoot>tr>td {
	border-color: #E6E6E7;
}
.tippers_data .box-header{
	background: transparent;
}
#all_sites_wrapper{
    background: transparent;
}
#all_sites{
	background: #ffffff;
	border: 1px solid #e6e6ec;
	font-size: 14px;
}
#all_sites th {
    color: #404849;
    text-transform: uppercase;
    font-family: 'Montserrat', sans-serif;
    font-weight: 600;
    vertical-align: middle;
    text-align: center;
    border-right: 1px solid #dddddd;
}
.customVal input, .customVal input:focus, .customVal input:active{
	border:none;
	outline-width: 0;
	text-align:center;
	line-height:55px;
	margin-bottom:0px;
}
.customVal td{
	padding: 0!important;
	line-height: 47px!important;
	text-align:  center!important;
	color:#a4a4a7;
}
.customVal .disable{
	cursor: no-drop
}
/* .customVal td:nth-child(6), .customVal td:nth-child(8), .customVal td:nth-child(11), .customVal td:nth-child(12), .customVal td:nth-child(13){
	background-color: rgb(235, 235, 228);
}
#all_sites tr:hover td:nth-child(6){
	background-color: rgb(235, 235, 228)!important;
} */
.customVal td {
    border-right: 1px solid #dddddd;
}
.obtrips_header_wrap{
	padding-right: 10px!important;	
}
.obtrips_header_wrap:after {
    display: none!important;
}
</style>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Main content -->
	<section class="content">
		<?php if($role == 'User'){ ?>
		<div class="form-group">
			<label>SELECT DATE</label>

			<div class="input-group date custom_date">
			  <input type="text" class="form-control pull-right datepicker" value="" id="datepicker">
			  <div class="input-group-addon">
				<i class="fa fa-calendar"></i>
			  </div>
			</div>
			 <h3 class="box-title">All 
			  <?php 
				if(!empty($selected_data)){
					echo $this->common_model->get_data_by_id('id','category', $selected_data[0]->cat_id); 	
				}
			  ?>
			  </h3>
			<!-- /.input group -->
		</div>
		<div class="box tippers_data">
           <!-- <div class="box-header">
             
            </div>
             /.box-header -->
            <div class="box-body">
              <table id="all_sites" class="table table-bordered table-striped datatable table-hover" style="width:100%;">
                <thead>
					<tr>
						<th style="line-height: 57px;width:10%;" rowspan="2">Tipper. No</th>
						<th style="line-height: 57px;width:10%;" rowspan="2">D.No.</th>
						<th style="text-align: center;background: #7accc8;width:12%;" class="obtrips_header_wrap" colspan="4">OB Trips</th>
						<th style="line-height: 57px;text-align: center;" class="obtrips_header_wrap" rowspan="2">HSD</th>
						<th style="line-height: 57px;text-align: center;" class="obtrips_header_wrap" rowspan="2">AVG/Trips</th>
						<th style="line-height: 57px;text-align: center;" class="obtrips_header_wrap" rowspan="2">KMR</th>
						<th style="line-height: 57px;text-align: center;" class="obtrips_header_wrap" rowspan="2">KMR</th>
						<th style="line-height: 57px;text-align: center;" class="obtrips_header_wrap" rowspan="2">Total</th>
						<th style="line-height: 57px;text-align: center;" class="obtrips_header_wrap" rowspan="2">AVERAGE</th>
						<th style="line-height: 57px;text-align: center;" class="obtrips_header_wrap" rowspan="2">LEAD</th>
						<th style="line-height: 57px;text-align: center;" class="obtrips_header_wrap"  rowspan="2">Status</th>
					</tr>
					<tr>
						<th style="text-align: center;width:15px;" class="obtrips_header_wrap"><span class="common_col">a</span></th>
						<th style="text-align: center;width:15px;" class="obtrips_header_wrap"><span class="common_col">b</span></th>
						<th style="text-align: center;width:15px;" class="obtrips_header_wrap"><span class="common_col">c</span></th>
						<th style="text-align: center;width:15px;" class="obtrips_header_wrap"><span class="common_col">total</span></th>
					</tr>
                </thead>
                <tbody>
				<?php 
				$countMachinesDataNames = 1;
				/* pt($selected_data); */
				foreach($selected_data as $machinesData){ 
					$id = $machinesData->id;
					$cat_id = $machinesData->cat_id;
					$cat_name = $this->common_model->get_data_by_id('id','category', $machinesData->cat_id);
					$v_no = $machinesData->v_no;
					$d_no = $machinesData->d_no;
					$m_no = $machinesData->m_no;
					$a = $machinesData->a;
					$b = $machinesData->b;
					$c = $machinesData->c;
					$total_ob = $machinesData->total_ob;
					$hsd = $machinesData->hsd;
					$avg_trips = $machinesData->avg_trips;
					$kmr_opening = $machinesData->kmr_opening;
					$kmr_closing = $machinesData->kmr_closing;
					$total = $machinesData->total;
					$average = $machinesData->average;
					$lead = $machinesData->lead;
					
				
				?>
                <tr class="customVal">
					<td class="vno"><input type="hidden" name="machine_id" class="machine_id" value="<?php echo $id; ?>"><?php echo $v_no; ?></td>
					<td class="dno"><?php echo ($d_no)?$d_no:'N/A'; ?></td>
					<!--td style="width: 15%;" class="obtrips_wrap">
						<table style="width: 100%;">
							<tr-->
								<td style="width: 4%;"><input class="a" style="width:100%;" type="text" name="a" value="<?php echo($a)?$a:''; ?>" title="Fill this value"></td>
								<td style="width: 4%;"><input class="b" style="width:100%;" type="text" name="b" value="<?php echo($b)?$b:''; ?>" title="Fill this value"></td>
								<td style="width: 4%;"><input class="c" style="width:100%;" type="text" name="c" value="<?php echo($c)?$c:''; ?>" title="Fill this value"></td>
								<td style="width: 4%;"><input class="td disable" style="width:100%;" type="text" disabled name="td" value="<?php echo($total_ob)?$total_ob:''; ?>"></td>
							<!--/tr>
						</table-->
					</td>
					<td><input class="hsd" style="width:100%;" type="text" name="hsd" value="<?php echo($hsd)?$hsd:''; ?>" title="Fill this value"></td>
					<td><input class="avgtrip disable" style="width:100%;" type="text" name="avgtrip" disabled value="<?php echo($avg_trips)?$avg_trips:''; ?>"></td>
					<td><input class="kmrrc" style="width:100%;" type="text" name="kmrrc" value="<?php echo($kmr_opening)?$kmr_opening:''; ?>" title="Fill this value"></td>
					<td><input class="kmrnew" style="width:100%;" type="text" name="kmrnew" value="<?php echo($kmr_closing)?$kmr_closing:''; ?>" title="Fill this value"></td>
					<td><input class="total disable" style="width:100%;" type="text" name="total" disabled value="<?php echo($total)?$total:''; ?>"></td>
					<td><input class="average disable" style="width:100%;" type="text" name="average" disabled value="<?php echo($average)?$average:''; ?>"></td>
					<td><input class="lead disable" style="width:100%;" type="text" name="lead" disabled value="<?php echo($lead)?$lead:''; ?>"></td>
					<td class="status"><i class="fa fa-refresh fa-spin data_loader" style="display:none;"></i><span class="btn customBtn" style="background: #337ab7;color: #ffffff;">update</span></td>
                </tr>
				<?php $countMachinesDataNames++; } ?>
                </tbody>
                <tfoot>
					<tr>
						<th style="width: 9%;line-height: 57px;" rowspan="2">Tipper. No</th>
						<th style="width: 9%;line-height: 57px;" rowspan="2">D.No.</th>
						<th style="width: 15%;text-align: center;" class="obtrips_header_wrap" colspan="4">OB Trips</th>
						<th style="line-height: 57px;text-align: center;" rowspan="2">HSD</th>
						<th style="line-height: 57px;text-align: center;" rowspan="2">AVG/Trips</th>
						<th style="line-height: 57px;text-align: center;" rowspan="2">KMR</th>
						<th style="line-height: 57px;text-align: center;" rowspan="2">KMR</th>
						<th style="line-height: 57px;text-align: center;" rowspan="2">Total</th>
						<th style="line-height: 57px;text-align: center;" rowspan="2">AVERAGE</th>
						<th style="line-height: 57px;text-align: center;" rowspan="2">LEAD</th>
						<th style="line-height: 57px;text-align: center;" rowspan="2">Status</th>
					</tr>
					<tr>
						<th style="width: 15%;text-align: center;">a</th>
						<th style="width: 15%;text-align: center;">b</th>
						<th style="width: 15%;text-align: center;">c</th>
						<th style="width: 15%;text-align: center;">total</th>
					</tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
		
		
		<?php }else{ 
		
			/* if(isset($editVehicle)){
				pt($editVehicle);
			}	 */	
			
		?>
		<h1>Add Vehicle here</h1>
		<!-- general form elements -->
		<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pad0">
			<div class="box box-primary addpad">
				<div class="box-header with-border">
				  <h3 class="box-title">Vehicle Data</h3>
				</div>
				<div style="padding:0px 15px;">
				<!-- /.box-header -->
				<?php
					if(isset($message['message']) && $message['check'] == 'f'){ ?>
					<div class="alert alert-danger">
					 <?php echo $message['message']; ?>
					</div>
				<?php }
				
				if(isset($message['message']) && $message['check'] == 't'){ ?>
				<div class="alert alert-success">
				  <?php echo $message['message']; ?>
				</div>
				<?php } 
				
				?>
				</div>
				<!-- form start -->
				<form method="POST" action="<?php echo base_url(); ?>admin/dashboard/vehicle" role="form" enctype="multipart/form-data">
					
					<?php	
					if(isset($editVehicle)){
						echo '<input type="hidden" name="edit" value="edit">';
						echo '<input type="hidden" name="id" value="'.$editVehicle[0]->id.'">';
					}	
					?>
				  <div class="box-body">
					<div class="form-group">
						<label>Site Names</label>
						<select class="form-control select2" id="site_id" style="width: 100%;" name="site_id">
						<option value="0">Select Site Name</option>
						<?php 
						
						foreach($siteNames as $siteNameData){ 
							$id = $siteNameData->id;
							$site_name = $siteNameData->name;
						?>
						  <option value="<?php echo $id; ?>" <?php echo(isset($editVehicle[0]->site_id) && $editVehicle[0]->site_id == $id)?'selected="selected"':''; ?>><?php echo $site_name; ?></option>
						<?php } ?>
						</select>
					</div>
					<div class="form-group">
						<label>Category Names</label>
						
						
						
						<select <?php echo(isset($editVehicle[0]->cat_id))?'':'disabled="disabled"'; ?> class="form-control select2" id="cat_id"  style="width: 100%;" name="cat_id">
						<option value="0">Select Category Name</option>
						<?php 
						
						foreach($categoryNameDatas as $categoryNameData){ 
							$cat_id = $categoryNameData->id;
							$cat_name = $categoryNameData->name;
							$cat_slug = $categoryNameData->slug;
							$cat_n_type = $categoryNameData->n_type;
							$site_id = $categoryNameData->site_id;
						?>
						  <option value="<?php echo $cat_id; ?>" <?php echo(isset($editVehicle[0]->cat_id) && $editVehicle[0]->cat_id == $cat_id)?'selected="selected"':''; ?> rel="<?php echo $cat_n_type; ?>"><?php echo $cat_name; ?></option>
						<?php } ?>
						</select>
					</div>
					<div class="form-group">
					  <label for="v_no">Vehicle No.</label>
					  <input type="text" class="form-control" <?php echo(isset($editVehicle[0]->v_no))?'':'disabled'; ?>  name="v_no" id="v_no" placeholder="Vehicle No." value="<?php echo(isset($editVehicle[0]->v_no))?$editVehicle[0]->v_no:''; ?>">
					</div>
					<div class="form-group" id="d_no_wrap" <?php echo(isset($editVehicle[0]->cat_id) && $editVehicle[0]->cat_id == '1')?'style="display:block;"':'style="display:none;"'; ?> >
					  <label for="d_no">D.No.</label>
					  <input type="text" class="form-control" <?php echo(isset($editVehicle[0]->d_no))?'':'disabled'; ?> name="d_no" id="d_no" placeholder="D.No." value="<?php echo(isset($editVehicle[0]->d_no))?$editVehicle[0]->d_no:''; ?>">
					</div>
					<div class="form-group" id="m_no_wrap" <?php echo(isset($editVehicle[0]->cat_id) && $editVehicle[0]->cat_id == '1')?'style="display:none;"':'style="display:block;"'; ?>>
					  <label for="m_no">M.No.</label>
					  <input type="text" class="form-control" <?php echo(isset($editVehicle[0]->m_no))?'':'disabled'; ?> name="m_no" id="m_no" placeholder="M.No." value="<?php echo(isset($editVehicle[0]->m_no))?$editVehicle[0]->m_no:''; ?>">
					</div>
				  </div>
				  <!-- /.box-body -->
				  <div class="box-footer">
					<?php if(!empty($editVehicle)){ ?>
						<button type="submit" class="btn btn-primary">Update</button>	
					<?php }else{ ?>
						<button type="submit" class="btn btn-primary">Submit</button>	
					<?php } ?>	
				  </div>
				</form>
			</div>
			  <!-- /.box -->
		</div>
		<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
			<div class="box">
            <div class="box-header">
              <h3 class="box-title">All Vehicles</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="all_sites" class="table table-bordered table-hover">
                <thead>
                <tr>
					<th>Sr. No</th>
					<th>Category Name</th>
					<th>Vehicle No</th>
					<th>D.No.</th>
					<th>M.No.</th>
					<th>Edit</th>
					<th>Delete</th>
                </tr>
                </thead>
                <tbody>
				<?php 
				$countMachinesDataNames = 1;
				foreach($machinesDataResult as $machinesData){ 
					$id = $machinesData->id;
					$cat_id = $machinesData->cat_id;
					$cat_name = $this->common_model->get_data_by_id('id','category', $machinesData->cat_id);
					$v_no = $machinesData->v_no;
					$d_no = $machinesData->d_no;
					$m_no = $machinesData->m_no;
					/* $extra_fields = $machinesData->extra_fields; */
				
				?>
                <tr>
					<td><?php echo $countMachinesDataNames; ?></td>
					<td><?php echo $cat_name; ?></td>
					<td><?php echo $v_no; ?></td>
					<td><?php echo ($d_no)?$d_no:'N/A'; ?></td>
					<td><?php echo ($m_no)?$m_no:'N/A'; ?></td>
					<td><a href="<?php echo base_url(); ?>admin/dashboard/vehicle/?edit=true&id=<?php echo $id; ?>" class="i_icon"><i class="fa fa-edit"></i></a></td>
					<td><a href="<?php echo base_url(); ?>admin/dashboard/vehicle/?delete=true&id=<?php echo $id; ?>" class="i_icon"><i class="fa fa-trash-o"></i></a></td>
                </tr>
				<?php $countMachinesDataNames++; } ?>
                </tbody>
                <tfoot>
                <tr>
					<th>Sr. No</th>
					<th>Category Name</th>
					<th>Vehicle No</th>
					<th>D.No.</th>
					<th>M.No.</th>
					<th>Edit</th>
					<th>Delete</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
		</div>
		<?php } ?>
	</section>
	<!-- /.content -->
</div>
  
