<?php
/**
 * Template Name: ZillowSearch
 *
 */

get_header(); 
global $current_user;
$role = user_role();
$agentID = $current_user->ID;

?>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/scroller.css" />
<link href="<?php echo get_template_directory_uri(); ?>/css/properties_listing.css" media="all" rel="stylesheet">
<?php echo get_template_part('css/properties_listing'); ?>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.mCustomScrollbar.js"></script>
<div id="primary" class="content-area" style="border-top:1px solid #ddd;">
	<main id="main" class="site-main" role="main">
		<?php
		// Start the loop.
		while ( have_posts() ) : the_post();

			// Include the page content template.
		the_content();

			// End of the loop.
		endwhile;
		
		global $wpdb;
		
		if(isset($_GET['city']) && !empty($_GET['city'])){
			$city = $_GET['city'];
			$query = "SELECT id,lat,paddress,home_type,zipcode,lot_sze,sold_date,exhoa,year_built,monthlyrent,lng,beds,full_baths,pprice,city,finished_feet FROM wp_home_facts WHERE city = '".$city."'";
			$locationsResult = $wpdb->get_results($query);
			$i = 0;
			$count = count($locationsResult);
			$locations = '';
			foreach($locationsResult as $location){
				$pid = $location->id;
				$latitude = $location->lat;
				$longitude = $location->lng;
				$zipcode = $location->zipcode;
				$address = $location->paddress;
				$sold_date = $location->sold_date;
				$Amount = $location->pprice;
				$year_built = $location->year_built;
				$city = $location->city;
				$beds = $location->beds;
				$monthlyrent = $location->monthlyrent;
				$exhoa = $location->exhoa;
				$bathroomsResult = $location->full_baths;
				$finishedSqFtResult = $location->finished_feet;
				$lotSize = $location->lot_sze;
				$hometype = $location->home_type;
				
				$completeAdd = '<span class=adressbar>'.$address.'</span>';
				$otherDetails = '<span class=additional_info><span class=left_sec_new><span class=outerRow><span class=inner_row><span class=inner_left>Price:</span><span class=inner_right>$'.get_val_by_number_format($Amount,true).'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>Beds:</span><span class=inner_right>'.$beds.'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>Baths:</span><span class=inner_right>'.$bathroomsResult.'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>Sqft:</span><span class=inner_right>'.$finishedSqFtResult.'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>Lot:</span><span class=inner_right>'.$lotSize.'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>Type:</span><span class=inner_right>'.$hometype.'</span></span></span></span><span class=right_sec_new><span class=outerRow><span class=inner_row><span class=inner_left>Built</span><span class=inner_right>'.$year_built.'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>Last Sold</span><span class=inner_right>'.$sold_date.'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>HOA</span><span class=inner_right>$'.$exhoa.'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>Rent</span><span class=inner_right>$'.get_val_by_number_format($monthlyrent,true).'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>Zillow Home ID</span><span class=inner_right>'.$pid.'</span></span></span><span class=outerRow><span class=inner_row><span class=inner_left>MLS#</span><span class=inner_right>82947832</span></span></span></span></span>';
				$infor = $completeAdd.$otherDetails;
				
				if($address){
					$polyLatLong = '';
					$locations .= '{"title": "'.$address.'", "lat": "'.$latitude.'", "lng": "'.$longitude.'","description": "'.$infor.'"},';
					if($latitude){
						if($i == $count-1){
							$polyLatLong .= '{"lat": '.$latitude.', "lng": '.$longitude.'}';
						}else{
							$polyLatLong .= '{"lat": '.$latitude.', "lng": '.$longitude.'},';	
						}
					}
					
					$i++;
				}
				/* $otherFinalDetails .= $bedroomsResult.' Beds'.', '.$bathroomsResult.' Baths'.', '.$finishedSqFtResult.' sqft'; */
			}
			
			$PropertiesCount = $i;
			$mapData = array(
				'mapid'=>'map_canvas',
				'location'=>$locations,
				'polyLatLong'=>$polyLatLong
				);
			get_map_by_location($mapData);
			?>
			<div id="search_main_container" class="container pad0">
			<div class="main_container_search" style="margin-top:0 !important;">

				<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 map_img no-pad pull-right">

					<div id="map_canvas" class="mapping" style="width:100%; height:100vh;"></div>
				</div>
				<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 leftsecn no-pad">
					<div class="right_panel_1 mCustomScrollbar">
							<div class="stickyWrap">	
								<div class="main_stripe">
									<div class="sortcustom">
										<span class="sorting_custom_wrap">
											<!--span class="showingno">Showing <span id="showingCountnow"></span> of <?php /* echo $count; */ ?> Homes</span-->
											<span class="showingno">Found <?php echo $count; ?>Homes In Austin Texas</span>
											<span class="sortingc asc">Sort
												<div class="funkyradio" id="sorting">	
													<div class="inner_funkyradio">	
														<span class="sortbyascwrapper">							
															<input type="radio" name="sortby" id="sortbyasc" checked="checked" class="sortby" value="asc" style="display:none"/>
															<label class="text" for="sortbyasc">A-Z</label>							
														</span>						
														<span class="sortbydeswrapper">
															<input type="radio" name="sortby" id="sortbydes" class="sortby" value="desc" style="display:none"/>		
															<label class="text" for="sortbydes">Z-A</label>		
														</span>												
														<div class="funkyradio-primary">							
															<input type="radio" class="sort" name="sort" value="0" id="price" />							<label for="price">Price</label>						
														</div>						
														<div class="funkyradio-primary">							
															<input type="radio" class="sort" name="sort" value="1" id="beds" />							
															<label for="beds">Beds</label>						
														</div>						
														<div class="funkyradio-primary">							
															<input type="radio" class="sort" name="sort" value="2"  id="bathrooms" />					
															<label for="bathrooms">Bathrooms</label>						
														</div>						
														<div class="funkyradio-primary">							
															<input type="radio" class="sort" name="sort" value="5"  id="address" />							<label for="address">Address</label>						
														</div>						
														<div class="funkyradio-primary">							
															<input type="radio" class="sort" name="sort" value="6"  id="location" />						<label for="location">Location</label>						
														</div>						
														<div class="funkyradio-primary">							
															<input type="radio" class="sort" name="sort" value="3"  id="sequare-feet" />				
															<label for="sequare-feet">Square feet</label>						
														</div>					
													</div>	
												</div>	
											</span>
										</span>

									</div>
									<div class="save_properties">
										<a class="more_filters_wrap save_btn more_filters">
											More Filters
											<i class="fa fa-angle-down" aria-hidden="true"></i>
										</a>
										<a class="regularbtn save_btn regularToggle border_bottom">
											<!--input type="radio" class="sort" name="sort" value="7"  id="regular" />
											<label for="regular"></label-->
											All
										</a> 
										<a class="save_btn savedToggle">
											<!--input type="radio" class="sort" name="sort" value="8"  id="saved" />
											<label for="saved"></label-->
											Saved
										</a> 
									</div>
								</div>	
							</div>	
							<div class="newFilters">
								<div class="newFilters_inner_wrap">
									<div class="newFilters_inner_wrap2">
										<span class="close"><i class="fa fa-times" aria-hidden="true"></i></span>
										<div class="row main_row_filters">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0">
												<span class="label">Price</span>
												<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
													<span class="sectwo">
														<select id="min" value="" class="selectpicker">
															<option value="">No min</option>
															<option value="1">1</option>
															<option value="50000">$50k</option>
															<option value="75000">$75k</option>
															<option value="100000">$100k</option>
															<option value="125000">$125k</option>
															<option value="150000">$150k</option>
															<option value="175000">$175k</option>
															<option value="200000">$200k</option>
															<option value="225000">$225k</option>
															<option value="250000">$250k</option>
															<option value="275000">$275k</option>
															<option value="300000">$300k</option>
															<option value="325000">$325k</option>
															<option value="350000">$350k</option>
															<option value="375000">$375k</option>
															<option value="400000">$400k</option>
															<option value="425000">$425k</option>
															<option value="450000">$450k</option>
															<option value="475000">$475k</option>
															<option value="500000">$500k</option>
															<option value="550000">$550k</option>
															<option value="600000">$600k</option>
															<option value="650000">$650k</option>
															<option value="700000">$700k</option>
															<option value="750000">$750k</option>
															<option value="800000">$800k</option>
															<option value="850000">$850k</option>
															<option value="900000">$900k</option>
															<option value="950000">$950k</option>
															<option value="1000000">$1M</option>
															<option value="1250000">$1.25M</option>
															<option value="1500000">$1.5M</option>
															<option value="1750000">$1.75M</option>
															<option value="2000000">$2M</option>
															<option value="2250000">$2.25M</option>
															<option value="2500000">$2.5M</option>
															<option value="2750000">$2.75M</option>
															<option value="3000000">$3M</option>
															<option value="3250000">$3.25M</option>
															<option value="3500000">$3.5M</option>
															<option value="3750000">$3.75M</option>
															<option value="4000000">$4M</option>
															<option value="4250000">$4.25M</option>
															<option value="4500000">$4.5M</option>
															<option value="4750000">$4.75M</option>
															<option value="5000000">$5M</option>
															<option value="6000000">$6M</option>
															<option value="7000000">$7M</option>
															<option value="8000000">$8M</option>
															<option value="9000000">$9M</option>
															<option value="10000000">$10M</option>
															<!--input type="text" id="min" name="min"-->
														</select>	
													</span>
												</div>
												<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
													<span class="secfour">
														<select id="max" value="" class="selectpicker">
															<option selected="">No max</option>
															<option value="4">$4</option>
															<option value="50000">$50k</option>
															<option value="75000">$75k</option>
															<option value="100000">$100k</option>
															<option value="125000">$125k</option>
															<option value="150000">$150k</option>
															<option value="175000">$175k</option>
															<option value="200000">$200k</option>
															<option value="225000">$225k</option>
															<option value="250000">$250k</option>
															<option value="275000">$275k</option>
															<option value="300000">$300k</option>
															<option value="325000">$325k</option>
															<option value="350000">$350k</option>
															<option value="375000">$375k</option>
															<option value="400000">$400k</option>
															<option value="425000">$425k</option>
															<option value="450000">$450k</option>
															<option value="475000">$475k</option>
															<option value="500000">$500k</option>
															<option value="550000">$550k</option>
															<option value="600000">$600k</option>
															<option value="650000">$650k</option>
															<option value="700000">$700k</option>
															<option value="750000">$750k</option>
															<option value="800000">$800k</option>
															<option value="850000">$850k</option>
															<option value="900000">$900k</option>
															<option value="950000">$950k</option>
															<option value="1000000">$1M</option>
															<option value="1250000">$1.25M</option>
															<option value="1500000">$1.5M</option>
															<option value="1750000">$1.75M</option>
															<option value="2000000">$2M</option>
															<option value="2250000">$2.25M</option>
															<option value="2500000">$2.5M</option>
															<option value="2750000">$2.75M</option>
															<option value="3000000">$3M</option>
															<option value="3250000">$3.25M</option>
															<option value="3500000">$3.5M</option>
															<option value="3750000">$3.75M</option>
															<option value="4000000">$4M</option>
															<option value="4250000">$4.25M</option>
															<option value="4500000">$4.5M</option>
															<option value="4750000">$4.75M</option>
															<option value="5000000">$5M</option>
															<option value="6000000">$6M</option>
															<option value="7000000">$7M</option>
															<option value="8000000">$8M</option>
															<option value="9000000">$9M</option>
															<option value="10000000">$10M</option>
														</select>
													</span>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0">
												<span class="label">Beds</span>
												<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
													<select id="Bedsmin" value="" class="selectpicker">
														<option value="default">No min</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
													</select>
												</div>
												<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
													<select id="Bedsmax" value="" class="selectpicker">
														<option value="default">No max</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
													</select>
												</div>
											</div>
										</div>
										<div class="row main_row_filters">
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0">
												<span class="label">Baths</span>
												<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
													<select id="Bathsmin" value="" class="selectpicker">
														<option value="default">No min</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
													</select>
												</div>
												<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
													<select id="Bathsmax" value="" class="selectpicker">
														<option value="default">No max</option>
														<option value="1">1</option>
														<option value="2">2</option>
														<option value="3">3</option>
														<option value="4">4</option>
														<option value="5">5</option>
														<option value="6">6</option>
													</select>
												</div>
											</div>
										</div>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 rowicons_div">
											<div class="row">
												<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pad0">
													<span class="label">Property Type</span>
												</div>
											</div>
											<div class="row margin0">
												<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pad0 common_home">
													<input type="radio" name="hometypes" class="hometypes" id="SingleFamily" value="Single Family">
													<label class="hometypeslabel" for="SingleFamily">
														<span class="img_wrap"><img src="<?php echo get_template_directory_uri().'/images/single_family_icon.png'; ?>"></span>
														Single Family
													</label>
												</div>
												<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pad0 common_home">
													<input type="radio" name="hometypes" class="hometypes" id="Condo" value="Condo">
													<label class="hometypeslabel" for="Condo">
													<span class="img_wrap"><img src="<?php echo get_template_directory_uri().'/images/condo_icon.png'; ?>"></span>
													Condo</label>
												</div>
												<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pad0 common_home">
													<input type="radio" name="hometypes" class="hometypes" id="Townhouse" value="Townhouse">
													<label class="hometypeslabel" for="Townhouse">
													<span class="img_wrap"><img src="<?php echo get_template_directory_uri().'/images/townhouse_icon.png'; ?>"></span>
													Town House</label>
												</div>
												<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pad0 common_home">
													<input type="radio" name="hometypes" class="hometypes" id="MultiFamily" value="Multi Family">
													<label class="hometypeslabel" for="MultiFamily">
													<span class="img_wrap"><img src="<?php echo get_template_directory_uri().'/images/multifamily_icon.png'; ?>"></span>
													Multi Family</label>
												</div>
												<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pad0 common_home">
													<input type="radio" name="hometypes" class="hometypes" id="Apartment" value="Apartment">
													<label class="hometypeslabel" for="Apartment">
													<span class="img_wrap"><img src="<?php echo get_template_directory_uri().'/images/apartment_icon.png'; ?>"></span>
													Apartment</label>
												</div>
												<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pad0 common_home">
													<input type="radio" name="hometypes" class="hometypes" id="Mobile" value="Mobile">
													<label class="hometypeslabel" for="Mobile">
													<span class="img_wrap"><img src="<?php echo get_template_directory_uri().'/images/mobile_icon.png'; ?>"></span>
													Mobile</label>
												</div>
											</div>
											<div class="row margin0">
												<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pad0 common_home">
													<input type="radio" name="hometypes" class="hometypes" id="CoopUnit" value="Coop Unit">
													<label class="hometypeslabel" for="CoopUnit">
													<span class="img_wrap"><img src="<?php echo get_template_directory_uri().'/images/CoopUnit_icon.png'; ?>"></span>
													Coop Unit</label>
												</div>
												<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pad0 common_home">
													<input type="radio" name="hometypes" class="hometypes" id="VacantLand" value="Vacant Land">
													<label class="hometypeslabel" for="VacantLand">
													<span class="img_wrap"><img src="<?php echo get_template_directory_uri().'/images/Vacant-Land.png'; ?>"></span>
													Vacant Land</label>
												</div>
												<div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 pad0 common_home">
													<input type="radio" name="hometypes" class="hometypes" id="Other" value="Other">
													<label class="hometypeslabel" for="Other">
													<span class="img_wrap"><img src="<?php echo get_template_directory_uri().'/images/townhouse_icon.png'; ?>"></span>
													Other</label>
												</div>
											</div>
											<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pad0 bottom_stripe">
												<span class="applyfilters">Apply Filters</span>
											</div>
										</div>
									</div>
								</div>
							</div>
							<table id="propertyListingTbl" class="propTab">
								<thead>
									<tr>
										<div class="sortContainer">
											<th class="propSort">Price</th>
											<th class="propSort" style="display:none !important;">Beds</th>
											<th class="propSort" style="display:none !important;">bathrooms</th>
											<th class="propSort">Sort By Sqft.</th>
											<th style="display:none !important;">Data</th>									<th class="propSort" style="display: none!important;">Address</th>
											<th class="propSort" style="display:none !important;">Location</th>
											<th class="propSort" style="display:none !important;">Hometype</th>
											<!--th class="propSort" style="display:none !important;">Saved</th>
											<th class="propSort" style="display:none !important;">unaved</th-->
										</div>
									</tr>
							<!--tr>
								<td colspan="3">
									<div class="main_titile">
										<span><strong>Showing <?php /* echo $PropertiesCount; */ ?> Properties</strong></span>
									</div>
								</td>
							</tr-->
						</thead>
						<tbody>	
							<?php
							$city = $_GET['city'];
							$listquery = "SELECT id,ptitle,user_id,home_type,lat,lng,images,sold_date,saved_status_user_id,paddress,zipcode,city,pprice,beds,lot_sze,full_baths,finished_feet,year_built,monthlyrent,exhoa FROM wp_home_facts WHERE city = '".$city."'";
							/* $wpdb->get_results($query); */
							$listingResult = $wpdb->get_results($listquery);	
							/* 	pt($listingResult); */
							$main_count = 1;	
							$map_count = 0;	
							foreach($listingResult as $location){
								$pid = $location->id;
								$user_id = $location->user_id;
								$saved_status_user_id = unserialize($location->saved_status_user_id);
								$latitude = $location->lat;
								$longitude = $location->lng;
								$rent = $location->monthlyrent;
								$hometype = $location->home_type;
								$address = $location->paddress;
								$zipcode = $location->zipcode;
								$Amount = $location->pprice;
								$sold_date = $location->sold_date;
								$lotSize = $location->lot_sze;
								$city = $location->city;
								$bedroomsResult = $location->beds;
								$bathroomsResult = $location->full_baths;
								$finishedSqFtResult = $location->finished_feet;
								$yBuilt = $location->year_built;
								$exhoa = $location->exhoa;
								$pImages = unserialize($location->images);
								$from = 'presult';
								$userArr = array($user_id);	
								$saved_array = $saved_status_user_id;
								if(is_array($saved_array) && in_array($agentID, $saved_array)){
								
								}
								if(is_array($saved_array) && in_array($agentID, $saved_array)){
									$value = 'saved';
								}else{
									$value = 'unsaved';
								}	
								?>
								<tr class="tdWrap <?php echo $value; ?>">								
									<td class="price" style="display:none!important;">
										<?php echo $Amount; ?>
									</td>
									<td class="beds" style="display:none!important;">
										<?php echo $bedroomsResult; ?>
									</td>
									<td class="bathrooms" style="display:none!important;">
										<?php echo $bathroomsResult; ?>
									</td>
									<td class="propertyCarouselWrap" style="display:none!important;">

									</td>
									<td class="desSec propertyDesc">
										<div id="markers"></div>
										<div class="main_wrap new_style_property">
											<div class="address">
											
												<a class="marker-link" data-markerid="<?php echo $map_count; ?>" ><?php echo $address; ?></a>
											</div>
											<div class="col-lg-4 col-md-4 col-sm-5 col-xs-12 pad0 pull-right">
												<div class="inner_4_wrap">
													<div class="owl-carousel" id="propertySlider">	
														<?php
														$imgCounts = count($pImages);
														if(!empty($pImages)){	
															$count = 1;
															foreach($pImages as $pImage){	
																$imageName = $pImage;
																/* if($imageName != 'null'){ */
																	$inser_url = site_url().'/wp-content/uploads/properties_gallery/'.$imageName;	
																	?>
																	<div class="item">										
																		<div class="sliderContainer" data="<?php echo $main_count; ?>" rel="<?php echo $count; ?>">	
																			<img src="<?php if($inser_url != '' ){ echo $inser_url; }else{ echo get_template_directory_uri().'/images/EstateDefault.jpg'; }  ?>">
																		</div>
																	</div>
																	<?php 
																	$count++;
																	/* } */
																} 

															}else{
																?>
																<img class="img-responsive" src="<?php echo get_template_directory_uri().'/images/EstateDefault.jpg'; ?>">
																<?php } ?>
															</div>
															<script>
																jQuery(document).ready(function(){
																	jQuery(".owl-carousel").owlCarousel({
																		slideSpeed : 300,											
																		loop:true,
																		margin:10,
																		nav:true,
																		items:1,
																		animateOut: 'fadeOut',
														/* afterMove: function (elem) {
														  var current = this.currentItem;
														  var src = elem.find(".owl-item").eq(current).find("img").attr('src');
														  console.log('Image current is ' + src);
														} */
													});
													// jQuery method on
													
												});
											</script>
										</div>
										<div class="images_count">
											<?php if($imgCounts == 0){ ?>
											N/A
											<?php }else{ ?>
											<span class="regular_count my_count_<?php echo $main_count; ?>">1</span> of <span class="total_count"><?php echo $imgCounts; ?></span>
											<?php } ?>
										</div>
									</div>

									<div class="col-lg-8 col-md-8 col-sm-7 col-xs-12 pad0">
										<div class="inner_8_wrap">
											
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 p-l-0">
												<div class="left_info common_style">
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Price</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r">$<?php echo get_val_by_number_format($Amount,true); ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Beds</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r"><?php echo $bedroomsResult; ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Baths</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r"><?php echo $bathroomsResult; ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Sqft</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r"><?php echo $finishedSqFtResult; ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Lot</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r"><?php echo $lotSize; ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Type</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r"><?php echo $hometype; ?></div> 
													</div>
												</div>
											</div>
											<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 p-l-0">
												<div class="right_info common_style">
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Built</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r"><?php echo $yBuilt; ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Last Sold</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r"><?php echo ($sold_date)?$sold_date:'N/A'; ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">HOA</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r">$<?php echo $exhoa; ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Rent</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r">$<?php echo get_val_by_number_format($rent,true); ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">Home ID</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r"><?php echo $pid; ?></div> 
													</div>
													<div class="borderwrap">
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 headlabel">MLS#</div> 
														<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pad0 text_align_r">82947832</div> 
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 pad0">
										<div class="buttonsWrap">
											<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 save">
											
												<?php if(!is_user_logged_in()){ ?>
												<a class="common_btn_style ls-modal-login" val="1" data-id="<?php echo $pid; ?>" rel="<?php echo $agentID; ?>">Save<img class
												="custom_loader" src="<?php echo get_template_directory_uri(); ?>/images/image.gif" style="display:none;"></a>
												<?php }else{ ?>
													<a class="common_btn_style ajax_saved" val="1" data-id="<?php echo $pid; ?>" rel="<?php echo $agentID; ?>">Save<img class
												="custom_loader" src="<?php echo get_template_directory_uri(); ?>/images/image.gif" style="display:none;"></a>
												
												<a class="common_btn_style ajax_remove" val="1" data-id="<?php echo $pid; ?>" rel="<?php echo $agentID; ?>" title="Removed From Save" style="display:none;">Remove<img class
												="custom_loader" src="<?php echo get_template_directory_uri(); ?>/images/image.gif" style="display:none;"></a>

												<?php } ?>	
											</div>
											<!--div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 moredetails">
												<a class="common_btn_style">More Details</a>
											</div-->
											<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 calculate">
												<?php if(!is_user_logged_in()){ ?>
												<a href="javascript:void(0);" class="ls-modal-login visulise_btn calculate_btn mainpPrice">
													<input type="hidden" id="hprice" name="price" value="<?php echo get_val_by_double_commas_format($Amount,true); ?>">
													<input type="hidden" id="hrent" name="rent" value="<?php echo $rent; ?>">
													<input type="hidden" id="hfrom" name="downpayment" value="<?php echo $from; ?>">
													CALCULATE</a>
													<?php }else{ ?>
													<a href="<?php echo get_the_permalink('107').'?price='.base64_encode($Amount).'&from='.$from.'&rent='.base64_encode($rent); ?>" class="visulise_btn calculate_btn">CALCULATE</a>
													<?php } ?>	

												</div>
											</div>
										</div>
									</div>
								</td>							
								<td class="address" style="display:none;">								
									<?php echo $address; ?>							
								</td>							
								<td class="location" style="display:none;">								
									<?php echo $city; ?>							
								</td>
								<td class="hometype_list" style="display:none;">								
									<?php echo $hometype; ?>							
								</td>
							</tr>
							<?php 
							$main_count++;
							$map_count++;
						}	 
						
						
						?>
						<div id="msgsResult" style="display:none;">
							<i class="fa fa-exclamation-triangle fa_custom" aria-hidden="true"></i>
							<p class="textWrap"><?php echo $msgsResult; ?></p>
							<div class="backbtnWrapper">
								<a class="searchPage" href="<?php echo site_url(); ?>">Back to Search Page</a>
							</div>
						</div>
						<script>
									/* jQuery(document).ready(function(){
										fnDrawCallback: function (settings) {
											jQuery("#propertyListingTbl").parent().toggle(settings.fnRecordsDisplay() > 0);
										}										
									});
									*/
								</script>
							</tbody>
						</table>	
								
					<link rel="stylesheet" href="//cdn.datatables.net/1.10.11/css/jquery.dataTables.min.css">
					<script src="//cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
					<script src="<?php echo get_template_directory_uri(); ?>/js/properties_listing.js"></script>
				</div>
			</div>

			

		</div>
		</div>
		<?php 	}else{ ?>
		<div class="fa_customWrapper">
			<!--i class="fa fa-exclamation-triangle fa_custom" aria-hidden="true"></i-->
			<p class="textWrap"><?php echo $msg; ?></p>
			<div class="backbtnWrapper">
				<a class="searchPage" href="<?php echo site_url(); ?>">
					Coming Soon
				</a>
			</div>
		</div>
		<?php } ?>
	</main><!-- .site-main -->
</div><!-- .content-area -->

<?php


get_footer(); ?>