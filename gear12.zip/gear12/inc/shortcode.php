<?php
	// Buttons Shortcode
	add_shortcode('button','gear_button_callback');
	function gear_button_callback( $attrs ) {
		$attrs = shortcode_atts(
			array(
				'text' => 'Read More',
				'link' => '#'
			),$attrs
		);
		extract($attrs);

		$html = '<a href="'. $link .'" class="gear-btn alt">'. $text .'</a>';
		return $html;
	}
?>