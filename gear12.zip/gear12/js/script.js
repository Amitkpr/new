$(function() {
    
    // Footer Animation
    jQuery(window).on('load resize', function() {
        var $winWidth     = jQuery(window).width();
        var $footerHeight = jQuery('.gear-footer-wrapper').outerHeight();
        if( $winWidth > 767 ) {
            jQuery('.gear-page-wrapper').css('margin-bottom', $footerHeight);
        }
    });

	// Form Submit on Icon Click	
	jQuery('.gear-submit').on('click', function() {
		jQuery(this).closest('form').submit();
	});

    // Fixed Menu Animation on Scroll
    var $window = jQuery(window), $header = jQuery('.gear-header'), headerTop = $header.offset().top;
    $window.scroll(function() {
        $header.toggleClass( 'sticky', $window.scrollTop() > headerTop );
    });

    // Gear Loader on Page Loading
    jQuery('.gear-loader .preloader').animate({ width: '100%' }, 2000, function() {
    	jQuery(this).closest('.gear-loader').hide();
    });

    // Gear Mobile Menu
    jQuery('.gear-header .mobile-menu').on('click', function() {
        jQuery(this).closest('.gear-header').find('ul').slideToggle();
    });

    // Gear Service Accordions
    jQuery('.service-accordion ul li h2').on('click', function() {
        var $thisService = jQuery(this).closest('.sa-article').find('p');
        jQuery('.service-accordion ul li p').not($thisService).slideUp();
        $thisService.stop(true, true).slideToggle(400);
    });

    // Gear Staff Member Bio
    jQuery('.gear-staff-members .gsm-image, .gear-staff-members .gsm-name').on('click', function() {
        var $thisStaff = jQuery(this).closest('.gsm-inner').find('.gsm-desc');
        jQuery('.gear-staff-members .gsm-inner .gsm-desc').not($thisStaff).slideUp();
        $thisStaff.stop(true, true).slideToggle(400);
    });
});