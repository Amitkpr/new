<?php /* Template Name: In the News Template */ ?>

<?php get_header(); ?>
<?php global $post, $gear_options; ?>

<section class="inthe-news-wrapper">
	<div class="gear-container text-center">
		<?php while( have_posts() ): the_post(); ?>
			<?php the_content(); ?>
		<?php endwhile; ?>
	</div>
	
	<div class="gear-container">
		<?php
		    $per_page = $gear_options['news_pagination'];
		    $paged    = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
			$args 	  = array(
				'post_type'      => 'news',
				'post_status' 	 => 'publish',
				'posts_per_page' => $per_page,
				'order' 		 => 'DESC',
				'paged' 		 => $paged
			);
			$gear_query = null;
			$gear_query = new WP_Query($args);
			if( $gear_query->have_posts() ) {
				$counter = 1;
				while( $gear_query->have_posts() ) : $gear_query->the_post();
					$image_id  = get_post_thumbnail_id();
	            	$image_url = wp_get_attachment_image_src($image_id,'large', true);
	            	$news_link = get_field( 'news_link', $post->id, true ); ?>
					<div class="news-grid text-center">
						<?php if( $counter % 2 == 0 ) { ?>
							<div class="news-inner">
		            			<figure class="news-img"><img src="<?php echo $image_url[0]; ?>"></figure>
							</div>
							<div class="news-inner">
								<article>
									<time datetime="1994-01-08"><?php echo get_the_date(); ?></time>
									<p>"<?php echo wp_trim_words( get_the_content(), '19', ''); ?>"</p>
									<div><a target="_blank" href="<?php echo $news_link; ?>">Read More</a></div>
								</article>
							</div>
						<?php } else { ?>
							<div class="news-inner">
								<article>
									<time datetime="1994-01-08"><?php echo get_the_date(); ?></time>
									<p>"<?php echo wp_trim_words( get_the_content(), '19', ''); ?>"</p>
									<div><a target="_blank" href="<?php echo $news_link; ?>">Read More</a></div>
								</article>
							</div>
							<div class="news-inner">
		            			<figure class="news-img"><img src="<?php echo $image_url[0]; ?>"></figure>
							</div>
						<?php } ?>
					</div>
				<?php $counter++; endwhile;
				if( function_exists( gear_pagination ) ) {
	            	gear_pagination( $gear_query->max_num_pages, "", $paged );
	        	}
		        wp_reset_query();
	    	}
		?>
	</div>
</section>

<?php get_footer(); ?>