<?php 

$errorsData = $this->session->flashdata('errorsData');
$message = $this->session->flashdata('message');
$machineDetails = $machineDetails;
$role = $userdetails[0]['role'];

?>
<style>
.error{
	color:red;
	margin-bottom:0px;
}
.error p{
	margin-bottom:0px;
}
</style>
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Main content -->
	<section class="content">
		<h1>Add Vehicle Details Here</h1>
		<!-- general form elements -->
		<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pad0">
			<div class="box box-primary addpad">
				<div class="box-header with-border">
				  <h3 class="box-title">Vehicle Data</h3>
				</div>
				<div style="padding:0px 15px;">
				<!-- /.box-header -->
				<?php
					if(isset($message['message']) && $message['check'] == 'f'){ ?>
					<div class="alert alert-danger">
					 <?php echo $message['message']; ?>
					</div>
				<?php }
				
				if(isset($message['message']) && $message['check'] == 't'){ ?>
				<div class="alert alert-success">
				  <?php echo $message['message']; ?>
				</div>
				<?php } 
				
				?>
				</div>
				<!-- form start -->
				<form method="POST" action="<?php echo base_url(); ?>admin/dashboard/addvehicledetails" role="form">
					<input type="hidden" name="user_id" value="">
					<div class="box-body">
						<div class="form-group">
							<label for="site_id">Site Name</label>
							<?php 
							/* pt($categoryNameData); */
							?>
							<select class="form-control select2" id="site_id" style="width: 100%;" name="site_id">
							<option value="0">Select Site Name</option>
							<?php 
							/* pt($categoryNameData); */
							foreach($siteNames as $siteNamesResult){ 
								$site_id = $siteNamesResult->id;
								$site_name = $siteNamesResult->name;
							?>
							  <option value="<?php echo $site_id; ?>"><?php echo $site_name; ?></option>
							<?php } ?>
							</select>
							<?php
							if(!empty($errorsData)){
								echo '<label class="error">'.$errorsData['site_id'].'</label>';
							}
							?>
						</div>
						<div class="form-group">
							<label for="cat_id">Category Name</label>
							<?php 
							/* pt($categoryNameData); */
							?>
							<select class="form-control select2" id="cat_id" style="width: 100%;" name="cat_id">
							<option value="0">Select Category Name</option>
							<?php 
							/* pt($categoryNameData); */
							foreach($categoryNameData as $categoryNameResult){ 
								$id = $categoryNameResult->id;
								$cat_name = $categoryNameResult->name;
							?>
							  <option value="<?php echo $id; ?>"><?php echo $cat_name; ?></option>
							<?php } ?>
							</select>
							<?php
							if(!empty($errorsData)){
								echo '<label class="error">'.$errorsData['cat_id'].'</label>';
							}
							?>
						</div>
						<div class="form-group">
							<label for="model">Model</label>
							<input type="text" class="form-control" name="model" id="model" placeholder="Model No.">
							<?php
							if(!empty($errorsData)){
								echo '<label class="error">'.$errorsData['model'].'</label>';
							}
							?>
						</div>
						<div class="form-group">
							<label for="dno">Door No.</label>
							<input type="text" class="form-control" name="dno" id="dno" placeholder="Door No.">
							<?php
							if(!empty($errorsData)){
								echo '<label class="error">'.$errorsData['dno'].'</label>';
							}
							?>
						</div>
						<div class="form-group">
							<label for="vehicle_no">Vehicle No.</label>
							<input type="text" class="form-control" name="vehicle_no" id="vehicle_no" placeholder="Vehicle No.">
							<?php
							if(!empty($errorsData)){
								echo '<label class="error">'.$errorsData['vehicle_no'].'</label>';
							}
							?>
						</div>
						<div class="form-group">
							<label for="chasis_no">Chasis No.</label>
							<input type="text" class="form-control" name="chasis_no" id="chasis_no" placeholder="Chasis No.">
							<?php
							if(!empty($errorsData)){
								echo '<label class="error">'.$errorsData['chasis_no'].'</label>';
							}
							?>
						</div>
						<div class="form-group">
							<label for="engine_no">Engine No.</label>
							<input type="text" class="form-control" name="engine_no" id="engine_no" placeholder="Engine No.">
							<?php
								if(!empty($errorsData)){
									echo '<label class="error">'.$errorsData['engine_no'].'</label>';
								}
							?>
						</div>
						
						<div class="form-group">
							<label for="pur_model">Purchase date</label>
							<input style="width:100%;" type="text" id="pur_model" class="pur_model form-control common_date_month_picker" name="pur_model" placeholder="Purchase date" value="">
							<?php
							
								if(!empty($errorsData)){
									echo '<label class="error">'.$errorsData['pur_model'].'</label>';
								}
								
							?>
						</div>
					</div>
					<!-- /.box-body -->
					<div class="box-footer">
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
				</form>
			</div>
			<!-- /.box -->
		</div>
		<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
			<div class="box">
            <div class="box-header">
              <h3 class="box-title">All Vehicles</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="all_sites" class="table table-bordered table-hover">
                <thead>
                <tr>
					<th>Sr. No</th>
					<th>Model</th>
					<th>Door No.</th>
					<th>Vehicle No.</th>
					<th>Chasis No.</th>
					<th>Engine No.</th>
                </tr>
                </thead>
                <tbody>
				<?php 
				$countMachinesDataNames = 1;
				foreach($machineDetails as $machineDetail){ 
					$id = $machineDetail->id;
					$model = $machineDetail->model;
					$dno = $machineDetail->dno;
					$vehicle_no = $machineDetail->vehicle_no;
					$chasis_no = $machineDetail->chasis_no;
					$engine_no = $machineDetail->engine_no;				
				?>
                <tr>
					<td><?php echo $countMachinesDataNames; ?></td>
					<td><?php echo $model; ?></td>
					<td><?php echo $dno; ?></td>
					<td><?php echo ($vehicle_no)?$vehicle_no:'N/A'; ?></td>
					<td><?php echo ($chasis_no)?$chasis_no:'N/A'; ?></td>
					<td><?php echo ($engine_no)?$chasis_no:'N/A'; ?></td>
                </tr>
				<?php $countMachinesDataNames++; } ?>
                </tbody>
                <tfoot>
                <tr>
					<th>Sr. No</th>
					<th>Model</th>
					<th>Door No.</th>
					<th>Vehicle No.</th>
					<th>Chasis No.</th>
					<th>Engine No.</th>
                </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
		</div>
		
	</section>
	<!-- /.content -->
</div>
  
