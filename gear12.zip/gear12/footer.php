	</div><?php global $post, $gear_options; ?>

	<?php $form_settings = get_field( 'ready_to_grow', $post->id, true ); ?>

	<div class="gear-footer-wrapper">

		<?php if ( ( $form_settings == 'yes' ) || ( is_singular( 'project' ) ) ) { ?>
			<div class="gear-getintouch text-center" <?php if( $gear_options['git_color'] ) { echo 'style="background: '.$gear_options['git_color'].'"'; } ?>>
				<div class="gear-container">
					<h2><?php echo $gear_options['git_text']; ?></h2>
					<a href="<?php echo $gear_options['git_link'] ?>" class="gear-btn"><?php echo $gear_options['git_btn']; ?></a>
				</div>
			</div>
		<?php } ?>

		<footer class="gear-footer">
			<div class="gear-container">
				<div class="column-1 footer-menus">
					<?php wp_nav_menu( array( 'theme_location' => 'footer', 'container' => false ) ); ?>
				</div>
				<div class="column-2 footer-addrs text-center">
					<?php echo $gear_options['footer_columns']; ?>
				</div>
				<div class="column-3 footer-mlist">
					<p class="footer-title text-center">Keep in Touch</p>
					<form action="#" method="POST">
						<input type="email" name="email" placeholder="Join Our Mailing List">
						<span class="gear-submit"></span>
					</form>
					<div class="gear-social">
						<ul>
							<?php
								$facebook  = $gear_options['facebook'];
								$twitter   = $gear_options['twitter'];
								$instagram = $gear_options['instagram'];
								if( $facebook ) {
									echo '<li><a href="'.$facebook.'" class="fa fa-facebook"></a></li>';
								}
								if( $twitter ) {
									echo '<li><a href="'.$twitter.'" class="fa fa-twitter"></a></li>';
								}
								if( $instagram ) {
									echo '<li><a href="'.$instagram.'" class="fa fa-instagram"></a></li>';
								}
							?>
						</ul>
					</div>
				</div>
			</div>

			<div class="gear-footer-sub">
				<div class="gear-container">
					<?php echo $gear_options['footer_copyright']; ?>
				</div>
			</div>
		</footer>
	</div>

	<?php wp_footer(); ?>

</body>
</html>